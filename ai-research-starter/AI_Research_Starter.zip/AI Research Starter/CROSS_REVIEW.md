# Optional cross-review before handover

Purpose: help the user obtain a separate assessment of completed AI-assisted research.

Consider another review before relying on a consequential conclusion, submitting work or publishing it. Match the reviewer to the question: a supervisor, mentor or subject specialist may be needed; another AI model can provide an additional assessment. Follow any review requirements of the destination.

For an AI cross-review, use a fresh session and preferably a different model family from the drafting model. A fresh chat with the same model is another check, not independent model-family review. Different providers do not guarantee uncorrelated errors or correct conclusions. If no separate review is available, retain the self-checked label and unresolved limitations.

## Prepare a small review bundle

Supply the question, intended use, scope and method; the exact draft version; the decisive source passages and claim records, including contrary evidence and access limits; relevant inputs and reproduction commands; actual check results; and the AI assistance disclosure.

Use originals where permitted and label abstracts or generated summaries. A long transcript is usually unnecessary. Remove private participant data, credentials and unrelated material. Check that institutional or organisational rules and project requirements, source licences and any data agreements permit sharing the material with the chosen service. Redaction alone does not settle those permissions. The human chooses the reviewer and approves any external sharing.

Where practical, first give the reviewer the question, method and key evidence without the draft conclusion. Preserve its initial assessment, then provide the draft for comparison. Record any prior exposure. This is an optional way to limit anchoring, not proof of independent errors.

## Paste this review request

Fill the fields and supply the listed materials. Do not claim that a check was run merely because its instructions are included.

```text
Review this AI-assisted research as a separate reviewer. Do not rewrite
the work or silently change its question, evidence or evaluation criteria.

Question and intended use: [details]
Scope, method and constraints: [details]
Exact draft version and files: [identifiers]
Evidence and source passages: [files or links; access limits]
Inputs, commands and observed check results: [details, or not applicable]
AI assistance disclosure and known limitations: [details]
Prior exposure to this work: [state it, or none known]

Check whether the method answers the question, decisive claims are
supported by the source passages, contrary evidence and uncertainty
are retained, calculations can be checked, and conclusions stay within
the evidence. Examine the actual AI and human contribution disclosure.

Distinguish a real defect from a preference, an access limitation or an
unresolved question. Do not infer source support from citations or a
successful script. Do not claim to have inspected inaccessible sources
or executed unavailable commands.

Return findings ranked by consequence. For each give the exact
claim or file section, supporting evidence, why it matters and the
smallest justified correction or next check. Identify what blocks the
stated use and what can remain as a disclosed limitation.

Finish with reviewed scope, checks actually performed, unchecked scope,
unresolved disagreements and a recommendation on readiness for the
stated use. Record your model/application and review role for disclosure.
The human retains the revision and release decisions.
```

## Resolve the findings

The human decides each material change. Keep the review and its disposition: corrected, accepted limitation, disputed with reasons, or deferred. Preserve disagreement and earlier versions. Recheck affected claims or code after a material correction and record the exact revised version.

Update the contribution disclosure with the reviewer and what it actually checked. A favourable review is evidence of that assessment, not proof of truth or permission to publish. Distinguish separate AI review, human source review and executed reproduction.
