# Research starter feedback: agent record

Purpose: record the assistant's observable actions, evidence, changes and omissions during a research starter trial.

Status: candidate form for the next pilot. See VERSION for the pack edition.

Complete this separately from the human form, using the session record. Cite a file section, command result or session message for each material assertion. Use "not done", "unavailable" or "unverified" where appropriate. Report partial completion and failures. Do not infer the user's satisfaction, understanding or motives, and do not describe unobservable model internals. A self-assessment is not independent verification.

## Session and environment

- Date and session label matching the human form, without personal identifiers:
- Pack version or archive identity, and how it was established:
- Application, declared model and any assisting models; distinguish visible labels from verified execution records:
- Operating system, Python command and version, with evidence:
- Project type and intended use, without private data:
- Files and instructions supplied at the start:
- Extra instructions, tools or human help added later, when they arrived, and the next recorded action:

## Question and decisions

- Original question and proposed use:
- Ending question and output produced; state any unfinished step:
- Follow-up questions recommended during research, their evidence and relevance, reusable materials identified, and the user's decisions:
- Reuse actually performed, with original version, new use, checks and remaining limits; distinguish it from suggested reuse:
- Did the scope stay the same, narrow, broaden, change direction or stop?
- For each material change: the evidence or limitation cited, alternatives considered, who proposed it, and the user's approval or unresolved decision. Give message or file references.
- Claims that were challenged, corrected or retained after review, with before and after wording:
- Contrary evidence sought and found, remaining search gaps, and any conclusion stronger than the checked evidence permits:

A changed direction is not automatically a better result. Distinguish an observed decision from the unverified correctness of its rationale. Record any comparison without the pack or other baseline; otherwise state "no baseline was run". Do not attribute an outcome to the pack alone when extra instructions or assistance were involved.

## Sources and human checking

- Search scope, exclusions and stopping point:
- Source access achieved: full text, abstract, registry record, search snippet or unavailable. Distinguish retrieved evidence from leads.
- Did tools supply original text, extracted text or generated summaries? Identify quotations that were not checked against the original.
- Were source copies and hashes saved? Give safe relative locators or state what is missing.
- Which consequential claims remain supported only by the drafting agent's judgement?
- Independent source review actually completed: reviewer, exact scope and evidence, or "none".
- Was separate end-of-project review recommended or performed? Record the exact version, reviewer, checks and disposition; distinguish recommendation from completion.
- Human source checks: record only checks observed or reported by the user, and label which. Do not infer that reading an output means opening its sources.

List a short, ranked set of sources the human should inspect next. For each, give the claim that depends on it, the precise passage or figure, access status, relevant limitations and why it matters. Explain quality and relevance in words; do not invent a numerical quality score. A proposed reading list is not a completed check.

| Priority | Source and passage | Claim or decision to check | Access and limitations | Why this check matters |
|---|---|---|---|---|
| | | | | |

## Execution and checker record

Record commands actually attempted. Include failed attempts and adaptations to the documented instructions. Use relative paths and remove secrets or machine identifiers.

| Command | Exit status | Observed result and evidence locator | What remains unchecked |
|---|---|---|---|
| | | | |

- Worked example: record separately the mechanical reproduction, explanation command, human or agent source-passage check, and changed-input demonstration. State what was skipped and why.
- Checker findings: for each material finding, state real defect, named false positive or substance-preserving rewrite; preserve the original finding, disposition and resulting change.
- Overrides, suppressed findings or altered checks, with reasons; state "none" only when supported:
- Access, permission, environment and tool failures; workarounds and unresolved effects:
- Time or resource use, only if measured:

## Limits and changes for the next pilot

- Disclosure supplied with the work, the actual AI tasks and human checks it records, and anything still unknown:
- Outputs ready for the user's stated use, with remaining verification requirements:
- Outputs requiring further work, and why:
- What the session cannot establish about research correctness or pack effectiveness:
- Changes proposed for the pack, each tied to an observed incident:
- Material differences from the human feedback, if it was later read; preserve both accounts and mark the order of completion:

Remove credentials, private work, personal data and internal machine paths before sharing. Provide a redacted account with necessary evidence excerpts; do not include a full transcript by default. The user controls any external sharing.
