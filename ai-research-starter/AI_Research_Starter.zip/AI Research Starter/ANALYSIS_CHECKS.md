# Optional analysis checks

Purpose: reuse selected source, sensitivity and monitoring checks when they address a material uncertainty in the project.

Use only the relevant check. These are prompts for a documented assessment, not an additional verification engine or proof that a result is correct.

## Sensitivity to analytical choices

When the answer depends on a definition, exclusion, parameter or modelling choice, name the choice and the conclusion it affects. Compare justified alternatives within a consistent population, unit and period. Preserve results that strengthen and weaken the preferred interpretation.

For a formal specification-curve exercise, ground each included specification in a named published source that used it, retain the citation and report the full declared set. Check that sufficiently distinct comparable specifications are available before committing. Consult the original methodological guidance. An informal sensitivity check is not automatically a specification-curve study.

Record the choice, alternative, source or justification, resulting change and what remains unresolved. Do not widen a range arbitrarily or select specifications because their result is favourable.

## Source binding and omitted qualifications

Check that the source supports the asserted subject, relationship and quantity together, with the same population, period, definition and epistemic status. Finding the name and number somewhere in a document is insufficient.

Inspect surrounding qualifications and contrary evidence. Ask which missing condition, excluded observation or alternative explanation would materially change the conclusion. Preserve it even when doing so weakens the main finding.

A word-match or number-match script can help locate discrepancies. It cannot establish semantic support, and its clean output does not replace reading the passage.

## Dated follow-up

For a finding that may change, record the next date or observable trigger, the primary source to inspect, what outcome would alter the interpretation and the decision it would inform. Distinguish an unchanged observation, changed evidence, unavailable evidence and a completed recheck.

Feed a justified follow-up into the question queue, identifying reusable material and its remaining limits. The human chooses whether to continue, reframe, combine or archive the work. Do not claim that a monitoring or reuse run occurred merely because instructions exist.

These prompts adapt selected retained NM AI Research sensitivity, grounding and monitoring practices. They do not inherit historical claims of validation, model-error independence or time saving.
