# Portable-pack scope

Purpose: identify the retained tools, adaptations and limits of this public pilot edition.

The research guide and continuing workflow follow the public portfolio map; WORKFLOW.md records the current-source limitation. Deliverable Filter and IDEACHECK are portable method editions derived from the existing author documents. They preserve method steps and qualifications while excluding historical numerical examples and internal trial administration. The guide does not claim that every prior project ran the same engine or that the framework has demonstrated superiority.

`vibecode_gate.py`, its existing test suite and `VIBECODE_FAILURE_GATES.md` are unchanged copies of the existing tools. They use Python's standard library and inspect only the explicit file list supplied.

`prosecheck.py` retains its house profile, with narrow named first-person exceptions described below. Internal working-history comments and local-context documentation were removed. The input-file read now uses a context manager because the original emitted an unclosed-file ResourceWarning. That earlier file-handling repair did not change detection. All portability changes are confined to this pack; the installed original is unchanged.

The prose checker reflects NM AI Research's house style. Its wording about generated-sounding prose is not an AI-authorship test. Its patterns do not establish intent, truth or academic misconduct. Do not infer that an unflagged file contains no private information; perform a contextual privacy and attribution check.

The infrastructure example is the unchanged public v7.1 bundle. Its own README states the CC BY 4.0 licence, contributions, frozen source period, commands and limits. The accompanying licence copy sits outside the example directory so the original package remains intact. Do not reinterpret its historical inputs as current measurements.

The first draft's newly invented record and manifest helpers are not included. This pack uses the requested existing tools and public worked example. No installed hook, API key, account configuration, private transcript or unpublished research dataset is included.

## Candidate revision

VERSION identifies this candidate. It adds portable working rules, an open method menu, route notes, a project notebook, separate feedback forms and clearer starting instructions. The workflow includes queue, selection, research and challenge, versioned handover, record alignment, monitoring, revision and archive branches. Windows interpreter alternatives are documented but have not been executed on Windows for this candidate.

The portable prose scanner excludes the initial in the literal phrase "Class I" and recognisable bibliographic author lists from first-person detection, and reports those exceptions. Capitalised possessives are now checked alongside their lowercase forms; the new regression cases exposed that earlier gap. Other first-person language on the same line remains eligible for detection. These bounded patterns cannot establish whether every ambiguous use is prose or a citation. Necessary unmatched cases still require a named contextual finding; do not rewrite a name or technical designation to obtain a pass.

All other detectors and scoring remain in force. The original checker tests remain, with added positive, negative and mixed-line regressions. The code gate and published example are unchanged. This candidate is not an independent acceptance or a new participant trial. No general workflow-effectiveness claim follows from local checks.

NM AI Research supplies the original approach and tools. OpenAI GPT-6 prepared this revision under the author's direction. The published example retains its existing licence and attribution; no new general redistribution licence is assigned to the other materials.

The pack explicitly supports AI-assisted research. AI_DISCLOSURE.md encourages a brief, fair statement of actual assistance and relevant conflicts. Agreed truthful wording is reused unless a material fact or requirement changes; repeated credit negotiation is outside the intended workflow. Prose checks do not establish human authorship or justify concealing AI contributions.

Checker diagnostics now refer to the actual provider and contributions, preserve human testimony and state that first-person matching is not an authorship test. This wording change does not alter the detector results or exit status.

The review-led revision clarifies the house-profile exception for genuine human first-person accounts, adds qualitative/interpretive method selection and a minimum working record, and states upload-permission checks for cross-review. It explicitly requires web search for discovery and contrary evidence, with supplied-source or human-search fallbacks. ANALYSIS_CHECKS.md reuses selected method patterns; no additional stack script is bundled.
