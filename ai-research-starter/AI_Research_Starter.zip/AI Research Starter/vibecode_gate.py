#!/usr/bin/env python3
"""Reject a bounded set of common generated-code defects before review."""

from __future__ import annotations

import argparse
import ast
import io
import json
import tokenize
from dataclasses import asdict, dataclass
from pathlib import Path

RULES = {
    "V001": "Python source does not decode or parse",
    "V002": "bare JSON literal in Python",
    "V003": "direct eval or exec call",
    "V004": "subprocess shell=True",
    "V005": "filesystem walk follows links",
    "V006": "broad exception is silently discarded",
    "V007": "invalid JSON syntax or encoding",
    "V008": "listed file cannot be read",
    "V009": "listed file type is not checked by this gate",
    "V010": "shell command through os.system or os.popen",
    "V011": "bidirectional control character in Python source",
    "V012": "duplicate key in a JSON object",
    "V013": "non-standard JSON constant NaN or Infinity",
}

# The nine explicit directional formatting characters named in CVE-2021-42574.
BIDI_CONTROLS = frozenset("\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069")
BROAD_EXCEPTIONS = frozenset({"Exception", "BaseException"})
OS_SHELL_FUNCTIONS = frozenset({"system", "popen"})


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    code: str
    message: str


def unreadable(path: Path, exc: OSError) -> Finding:
    return Finding(str(path), 0, "V008", f"cannot read file: {exc.strerror or exc}")


def is_broad_exception(node: ast.expr | None) -> bool:
    if node is None:
        return True
    if isinstance(node, ast.Name):
        return node.id in BROAD_EXCEPTIONS
    if isinstance(node, ast.Tuple):
        return any(is_broad_exception(element) for element in node.elts)
    return False


def is_silent(body: list[ast.stmt]) -> bool:
    """Return whether a handler body only passes or evaluates a constant such as `...`."""
    return all(
        isinstance(statement, ast.Pass)
        or (isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Constant))
        for statement in body
    )


def os_shell_names(tree: ast.AST) -> tuple[set[str], set[str]]:
    """Return local names bound to the os module and to os.system or os.popen."""
    modules: set[str] = set()
    functions: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "os":
                    modules.add(alias.asname or "os")
        elif isinstance(node, ast.ImportFrom) and node.module == "os" and node.level == 0:
            for alias in node.names:
                if alias.name == "*":
                    functions.update(OS_SHELL_FUNCTIONS)
                elif alias.name in OS_SHELL_FUNCTIONS:
                    functions.add(alias.asname or alias.name)
    return modules, functions


def bidi_findings(path: Path, text: str) -> list[Finding]:
    findings: list[Finding] = []
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    for number, line in enumerate(lines, start=1):
        controls = sorted({character for character in line if character in BIDI_CONTROLS})
        if controls:
            points = ", ".join(f"U+{ord(character):04X}" for character in controls)
            findings.append(
                Finding(str(path), number, "V011", f"bidirectional control character: {points}")
            )
    return findings


def inspect_python(path: Path) -> list[Finding]:
    """Return static findings with low false-positive risk."""
    try:
        data = path.read_bytes()
    except OSError as exc:
        return [unreadable(path, exc)]
    try:
        tree = ast.parse(data, filename=str(path))
    except SyntaxError as exc:
        return [Finding(str(path), exc.lineno or 0, "V001", f"syntax error: {exc.msg}")]
    except ValueError as exc:
        return [Finding(str(path), 0, "V001", f"source does not decode: {exc}")]
    encoding, _ = tokenize.detect_encoding(io.BytesIO(data).readline)
    findings = bidi_findings(path, data.decode(encoding))
    os_modules, os_functions = os_shell_names(tree)
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Load)
            and node.id in {"null", "true", "false"}
        ):
            findings.append(
                Finding(str(path), node.lineno, "V002", f"bare JSON literal in Python: {node.id}")
            )
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec"}:
                findings.append(
                    Finding(str(path), node.lineno, "V003", f"dynamic execution call: {node.func.id}")
                )
            if (
                isinstance(node.func, ast.Attribute)
                and node.func.attr in OS_SHELL_FUNCTIONS
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id in os_modules
            ) or (isinstance(node.func, ast.Name) and node.func.id in os_functions):
                findings.append(
                    Finding(str(path), node.lineno, "V010", "shell command through the os module")
                )
            for keyword in node.keywords:
                if (
                    keyword.arg == "shell"
                    and isinstance(keyword.value, ast.Constant)
                    and keyword.value.value is True
                ):
                    findings.append(Finding(str(path), node.lineno, "V004", "subprocess shell=True"))
                if (
                    keyword.arg == "followlinks"
                    and isinstance(keyword.value, ast.Constant)
                    and keyword.value.value is True
                ):
                    findings.append(
                        Finding(str(path), node.lineno, "V005", "filesystem walk follows links")
                    )
        if isinstance(node, ast.ExceptHandler):
            if is_broad_exception(node.type) and is_silent(node.body):
                findings.append(
                    Finding(str(path), node.lineno, "V006", "broad exception is silently discarded")
                )
    return findings


def inspect_json(path: Path) -> list[Finding]:
    """Reject malformed or ambiguous JSON. Schema support is a separate project gate."""
    try:
        data = path.read_bytes()
    except OSError as exc:
        return [unreadable(path, exc)]
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        return [Finding(str(path), 0, "V007", f"invalid JSON: not UTF-8 at byte {exc.start}")]
    findings: list[Finding] = []

    def reject_duplicates(pairs: list[tuple[str, object]]) -> dict[str, object]:
        seen: set[str] = set()
        for key, _ in pairs:
            if key in seen:
                findings.append(Finding(str(path), 0, "V012", f"duplicate JSON key: {key!r}"))
            seen.add(key)
        return dict(pairs)

    def reject_constant(name: str) -> float:
        findings.append(Finding(str(path), 0, "V013", f"non-standard JSON constant: {name}"))
        return float(name)

    try:
        json.loads(text, object_pairs_hook=reject_duplicates, parse_constant=reject_constant)
    except json.JSONDecodeError as exc:
        return [Finding(str(path), exc.lineno, "V007", f"invalid JSON: {exc}")]
    return findings


def run(paths: list[Path]) -> list[Finding]:
    """Inspect the explicit Python and JSON file list without directory traversal."""
    findings: list[Finding] = []
    for path in paths:
        if path.suffix == ".py":
            findings.extend(inspect_python(path))
        elif path.suffix == ".json":
            findings.extend(inspect_json(path))
        else:
            findings.append(
                Finding(str(path), 0, "V009", "not a .py or .json file; remove it from the list")
            )
    return sorted(findings, key=lambda item: (item.path, item.line, item.code))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="+", type=Path)
    parser.add_argument("--json", action="store_true", help="print one JSON result object")
    args = parser.parse_args(argv)
    findings = run(args.paths)
    if args.json:
        result = {
            "status": "fail" if findings else "pass",
            "files_listed": len(args.paths),
            "findings": [asdict(finding) for finding in findings],
        }
        print(json.dumps(result, indent=2))
        return 1 if findings else 0
    if findings:
        for finding in findings:
            print(f"{finding.path}:{finding.line}: {finding.code} {finding.message}")
        return 1
    print(f"PASS: {len(args.paths)} explicitly listed files checked")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
