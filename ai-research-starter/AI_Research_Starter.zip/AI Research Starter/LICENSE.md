# Licences

AI Research Starter, public pilot edition, shared by NM AI Research.

- **Documents** (every Markdown file outside `examples/`): Creative Commons Attribution 4.0 International
  (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/. You may share and adapt them for any purpose, with
  credit to NM AI Research and a link to the licence.
- **Scripts** (`style_check.py`, `code_gate.py` and `tests/`): the MIT licence below.
- **The examples and method map** in `examples/` use CC BY 4.0: the infrastructure example's licence is in `examples/AI_INFRASTRUCTURE_LICENSE.txt`, and the forecast scorecard example's licence is in `examples/FORECAST_SCORECARD_LICENSE.txt`.

## MIT licence (scripts)

Copyright (c) 2026 NM AI Research

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
