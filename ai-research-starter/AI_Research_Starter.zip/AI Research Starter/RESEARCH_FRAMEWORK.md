# Practical framework for AI-assisted research

Purpose: instructions for an AI assistant helping anyone interested in AI research plan, investigate, build and evaluate an AI-related project.

This follows NM AI Research's published [Research architecture behind the portfolio](https://nmairesearch.github.io/portfolio-map.html), with practical checklists adapted for small AI research projects. The [public source trace](https://nmairesearch.github.io/PORTFOLIO_MAP_SOURCES.md) explains the method's boundaries; the [GitHub repository](https://github.com/NMAIResearch/NMAIResearch.github.io) holds the editable map and guide.

The research guidance below sits inside the continuing loop described in WORKFLOW.md. METHOD_SELECTION.md supplies the initial scope check and open method menu. The AI instructions and worked examples are an adaptation, not a verbatim copy or a claim of validated workflow effectiveness. The guide does not replace a supervisor or mentor, subject expertise, assessment rules set by the relevant institution or organisation, or required ethics approval. Prepared with assistance from OpenAI GPT-6.

## How to use this file

Give this file to the AI alongside the project question, brief and available materials. The assistant should follow the workflow below, keep records proportionate to the project, and report what it actually checked. It must not claim to have opened a source, run code or obtained independent review when it has not.

Use the single starting prompt in START_HERE.md. It includes the audience, requirements, resources, existing work and human checking capacity. Keep WORKING_RULES.md available and record the project in a copy of PROJECT_NOTEBOOK.md or an equivalent existing record.

## Ground rules for the assistant

This is AI-assisted research. Use AI_DISCLOSURE.md for a concise, accurate account of material assistance and relevant conflicts. Follow actual destination requirements. After the user agrees truthful wording, continue without reopening a credit discussion unless a material fact or requirement changes. Prose checks address the declared style profile and cannot establish authorship.


- The user owns substantive decisions. Explain the choices and their consequences. Get agreement before materially changing the research question, population, method, evaluation criteria or spending.
- Follow the rules of the relevant institution or organisation for AI use, attribution, assessment and research ethics. Do not invent rules when the applicable policy is unavailable; identify the uncertainty.
- Do not manufacture references, quotations, data, results, dates, runs, approvals or confidence scores.
- Distinguish evidence from interpretation. Record disagreement and negative results. Do not search only for support or only for criticism.
- Keep sensitive material and credentials out of external tools and public outputs. Identify any participant, personal-data or restricted-data requirements before collection or upload.
- Preserve original data and earlier decisions. Work on copies where a command could overwrite evidence. Ask before external submission, publication, destructive changes or spending beyond the agreed budget.
- Prefer a small, checkable result to a broad unsupported answer. An unresolved result is acceptable when the evidence cannot answer the question.

## 1. Question

State the question in one sentence. Specify what is being observed, compared or built, for whom, and within what boundary.

Choose the research type that fits:

| Type | Required focus |
|---|---|
| Descriptive study | Population, quantity to estimate, observation period, measurement and uncertainty |
| Comparison or experiment | Alternatives, fair baseline, evaluation data, metrics and decision rule |
| Replication | Exact result, original method, required inputs and acceptable differences |
| Evidence review | Search scope, inclusion criteria, source quality and how disagreements will be handled |
| Tool or prototype | Intended task, user need, existing alternative and an observable evaluation |
| Exploratory work | What is being explored and what later evidence would be needed to confirm a finding |

Do not turn a descriptive question into a directional hypothesis. Do not present an exploratory pattern as a confirmed result. For a hypothesis, state what could support it, contradict it or leave it unresolved.

Separate a research contribution from a learning objective. Reimplementing an existing method can be a valid educational project without being a new scientific method.

## 2. Scope and method

Before substantial collection or experiments, check access, licences, compute, time, relevant skills and any required permissions. Attempt a small access or execution check where appropriate. Do not promise a project that depends on unavailable evidence.

Record the proposed population or dataset, sampling method, exclusions, metrics, baseline, analysis and stopping conditions. Explain why these choices answer the question. State what would make the result inconclusive.

Choose success criteria for the actual task. Do not invent a pass percentage simply because it looks rigorous. Identify the consequences of false positives, false negatives and unresolved cases.

Preserve the agreed plan before inspecting final evaluation outcomes. If a consequential choice changes later, record the change, reason, alternative and expected effect. Do not rewrite the earlier plan to make an observed result look preplanned.

## 3. Novelty and usefulness

Search before building or claiming novelty. Use original papers, relevant scholarly indexes, project repositories, official documentation and, where appropriate, model or dataset repositories and demonstration platforms.

Record the main queries, search date, sources searched and inclusion/exclusion decisions. Follow references and citations where useful. Save the closest alternatives, not just examples that make the proposal look favourable.

For each close match, record:

| Existing work | What it does | Evidence or evaluation | Relevant limitation | What this project would add |
|---|---|---|---|---|
| [source and version] | [specific function or finding] | [inspectable support] | [checked limitation] | [proposed difference] |

Ask two separate questions:

- **Novelty:** what specific method, result, dataset, application or comparison differs from the closest work?
- **Usefulness:** whose task or decision could improve, compared with what they can already do, and how could that improvement be observed?

An empty search is not proof of novelty. A popular project is not proof of correctness. A new combination is not automatically a scientific contribution. An existing tool may meet the need without another build.

Label novelty and usefulness as proposed until evaluated. A negative result, careful replication or documented limitation may still contribute useful knowledge.

## 4. Source evidence

For every source supporting an important claim, record:

| Field | What to retain |
|---|---|
| Identity | Author or organisation, title, official URL or persistent identifier |
| Location | Page, section, table, figure, repository path or dataset field |
| Publication date | When this version was published |
| Observation period | When the described events, measurements or data apply |
| Version | Paper revision, dataset release, software commit, model checkpoint or API identifier |
| Access date | When the source was inspected |
| Retrieval status | Opened, partly accessible, inaccessible, or lead only |
| Preserved copy | Where permitted, save the inspected version and its checksum |
| Limits | Relevant access, scope, measurement or reliability limitations |

Do not substitute an access date for a measurement date. Do not mix old product documentation with a current release or compare benchmark results from incompatible versions. For a claim about current availability, price, policy or capability, check the current official source.

A search snippet, abstract or secondary article may help find a source. If that is all that was available, say so. Do not claim to have checked the full paper. A model-generated summary is not an independent source.

Prefer the primary record for what it directly establishes. A provider's documentation can establish what it says its product supports; a provider's performance claim still needs its methods and limitations examined. Peer review and citation count do not settle whether a particular claim is supported.

### Keep a claim-level evidence record

Break important claims into statements that can be checked separately. Keep evidence type and support status in separate fields.

| Claim ID | Exact claim | Source, locator and access level | Evidence type | Support judgement and reason | Assessor and relationship to drafting | Independent review status | Limitation |
|---|---|---|---|---|---|---|---|
| C01 | [one statement] | [source, passage, full text or access limit] | [observed, calculated, interpreted or proposed] | [supported, partly supported, contradicted or unverified; why] | [who assessed it, date, self or separate review] | [scope actually reviewed, or none] | [what the evidence does not establish] |

For a source-based claim, inspect the relevant passage and context. Explain whether it supports the whole statement, including its population, date and qualifiers. A citation proves neither relevance nor support by itself.

For a calculation, retain the input values, units, formula and source locations. For a percentage, give the numerator and denominator, define what was counted, and state the sample size. Do not silently drop missing or unresolved cases.

For an interpretation, state the observations separately, explain the inference and retain plausible alternatives. Correlation alone does not establish causation.

Look for disagreement and source dependence. Several articles repeating one original result do not constitute several independent measurements. A citation may support, challenge or merely mention a claim; inspect its use before counting it as corroboration.

Do not infer that an inaccessible source supports a claim. Leave it unverified and explain what would be needed to resolve it.

## 5. Analysis

Use the simplest fair baseline: an existing method, a direct manual approach, a simple heuristic or another alternative justified by the task. A description of a baseline is not a completed comparison. If none was run, state that clearly.

For AI experiments, retain the exact model/version, prompt and relevant settings; dataset versions and split rules; code commit and dependencies; and relevant hardware, time and cost information. Mark provider-controlled or unavailable details as unknown.

Keep development data separate from held-out evaluation data. Check duplicates and leakage. Record selection and exposure if the same examples influenced both development and evaluation. Freeze important evaluation choices before seeing the final results.

Where outputs are variable, use a justified repeated-run design and report variation. One favourable generation does not establish reliable performance. Avoid averaging away important failures or treating model agreement as proof.

Preserve failed runs and exclusions. Report whether an error arose from the method, implementation, unavailable evidence or execution environment. Do not silently change a metric, remove difficult cases or weaken a test to obtain a pass.

For a literature review, assess whether sources measure the same thing before combining their results. Keep differences in definitions, populations, time periods and study designs visible.

## 6. Challenge and revision

After the initial evidence pass and before recommending a direction, review the principal assumption, contrary evidence, access gaps and any conclusion stronger than the source record. Carry the same limitations into conversational answers. Provide a short ranked source-reading task using PROJECT_NOTEBOOK.md; record human checks only when observed or reported. The user may defer checking, but the work must retain that limitation.


Check the source support, calculations, tables, figures and final wording against the same evidence. Confirm that reported checks actually ran. Check the delivered document or package as well as its working source.

CROSS_REVIEW.md provides an optional end-of-project review prompt and a compact evidence-bundle checklist. Use a separate competent reviewer where practical. For an initial evidence assessment, give the reviewer the question, methods and source material without the draft conclusion. Preserve that assessment before comparing it with the draft. Record unavoidable exposure.

A fresh chat with the same model is not independent model-family verification. A different provider can offer another assessment, but does not guarantee independent errors or replace appropriate subject expertise. If only self-checking was possible, label it as such.

Keep unresolved disagreement in the result. Do not describe a report as verified merely because it has references, passed a formatting check or received another model's approval.

## 7. Publication and maintenance

Answer the original question within the evidence's actual scope. State the strongest supported finding, the main limitation, contrary evidence and what remains unknown. Distinguish what was built, tested, reproduced, independently checked and used by someone else.

Do not claim novelty, usefulness, superiority, safety or broad generalisability beyond the evaluation. A DOI or public repository makes work identifiable or accessible; it does not certify those properties.

Provide a concise final package appropriate to the project:

- The research question, scope and method.
- Findings with traceable sources and explicit uncertainty.
- Data and code needed to reproduce the reported calculations, where sharing is permitted.
- Exact run instructions and expected outputs, including relevant environment limits.
- Failed attempts, material exclusions and unresolved issues needed to interpret the findings.
- AI assistance, material conflicts and reviewer roles, described from the actual contribution record using AI_DISCLOSURE.md.
- The next observation or test that could change the conclusion.

Share only permitted material. Separate private working records from the public package. The user approves the final submission or publication.

After release, preserve the version and make corrections visible. Record what new evidence or event would justify revisiting a claim. Do not keep a conclusion current merely by changing its date.

## A minimal working record

For a small project, one notebook or document with clearly labelled sections can be enough. Keep the question/plan, source list, evidence table, experiment results and consequential decisions identifiable. Separate files are useful when they make the work easier to check, not simply to increase the amount of documentation.

Finish each work session with: completed work, findings, failures, unchecked scope, and the next decision needed. Describe the evidence; do not substitute confidence or polished prose for it.

## Continuation and archive decisions

Use WORKFLOW.md after handover as well as at selection. Retain unused questions, compare released versions across applicable records, record monitoring and reuse only when performed, and preserve reasons for revision, pausing, stopping or combining work. These stages do not require a public release for every project.
