# AI Research Starter

AI Research Starter is a public pilot pack from NM AI Research for planning, investigating, challenging and documenting a checkable project with an AI assistant. It is for anyone interested in AI research, including students, researchers and practitioners, and people reviewing their work. It provides research guidance, a starting prompt, a project notebook, small checkers and two historical reproduction examples. This pack is not evidence of improved research quality.

## What's inside

| File | Use |
|---|---|
| [START_HERE.md](START_HERE.md) | One starting prompt with project details to fill |
| [WORKING_RULES.md](WORKING_RULES.md) | Short common rules for decisions, evidence, checks and permission |
| [WORKFLOW.md](WORKFLOW.md) | Continuing workflow and return paths |
| [METHOD_SELECTION.md](METHOD_SELECTION.md) and [methods/](methods/) | Open method menu, scope check and short route notes |
| [RESEARCH_FRAMEWORK.md](RESEARCH_FRAMEWORK.md) | Detailed research guidance |
| [ANALYSIS_CHECKS.md](ANALYSIS_CHECKS.md) | Optional sensitivity, source-binding and dated follow-up checks |
| [CROSS_REVIEW.md](CROSS_REVIEW.md) | Optional separate review, a small evidence bundle and a pasteable prompt |
| [AI_DISCLOSURE.md](AI_DISCLOSURE.md) | Brief, fair disclosure and a stop condition for repeated credit discussion |
| [PROJECT_NOTEBOOK.md](PROJECT_NOTEBOOK.md) | Scope, evidence, source-reading tasks, decisions and execution record |
| [IDEACHECK.md](IDEACHECK.md) | Prior work and proposed contribution |
| [DELIVERABLE_FILTER.md](DELIVERABLE_FILTER.md) | Announced claims and practical delivery constraints |
| [SOURCE_AND_REPRODUCTION.md](SOURCE_AND_REPRODUCTION.md) | Source support, preservation and reproducible calculation |
| [style_check.py](style_check.py) | Configured house-style and internal-marker patterns; not fact or authorship detection |
| [code_gate.py](code_gate.py) and [CODE_FAILURE_GATES.md](CODE_FAILURE_GATES.md) | Bounded Python/JSON checks and project-specific requirements |
| [FAILURE_CASES.md](FAILURE_CASES.md) | Mistakes and appropriate responses to blocked checks |
| [FEEDBACK_HUMAN.md](FEEDBACK_HUMAN.md) and [FEEDBACK_AGENT.md](FEEDBACK_AGENT.md) | Separate experience and execution accounts |
| [examples/ai-infrastructure-v7.1/](examples/ai-infrastructure-v7.1/) | Unchanged historical reproduction example and its limits |
| [examples/forecast-scorecard-v0.5/](examples/forecast-scorecard-v0.5/) | Second unchanged historical reproduction example and its limits |
| [examples/FORECAST_SCORECARD_METHOD_MAP.md](examples/FORECAST_SCORECARD_METHOD_MAP.md) | Kit steps mapped to inspectable bundle records and missing stages |
| [tests/](tests/) | Tests of the supplied checkers; these do not test your research |
| [PORTABILITY.md](PORTABILITY.md) | Changes, attribution, licence and verification boundaries |

## Quick start

1. Unzip the pack and read this page. Provide the assistant with this pack, your question, any brief and the materials it may use.
2. Open [START_HERE.md](START_HERE.md). Fill its project, audience, deadline, resources and existing-work fields, then paste the enclosed prompt into a new conversation. Use "unknown" or "not applicable" where appropriate. The prompt works with other assistants too.
3. The assistant should explain the process, what it will produce and what you will need to decide or read. Agree the intended outcome and a small initial plan.

Edition: see [VERSION](VERSION). This public pilot is shared for trial and feedback. Review status is recorded separately against the exact file identities.

This is AI-assisted research. Use a short, fair note about the help actually used and any relevant conflict, following [AI_DISCLOSURE.md](AI_DISCLOSURE.md) and your actual brief requirements. Once accurate wording is agreed, the assistant should move on. Style checks do not establish authorship or research correctness.

You own substantive decisions and any release. Follow applicable requirements from your institution or organisation, as well as research-ethics and data-use requirements. This pack does not replace a supervisor, mentor or subject specialist.

## Plan the work

1. Use [METHOD_SELECTION.md](METHOD_SELECTION.md) to choose the route. Read only the relevant route note initially; other methods remain available.
2. Before live research, the assistant should confirm that web search is available, search for original sources and accessible versions, and record its queries and search limits. A URL fetch or search snippet alone is not a source-support check. If live search is unavailable, agree work from supplied sources or a search task for the human.
3. Keep the project record in a copy of [PROJECT_NOTEBOOK.md](PROJECT_NOTEBOOK.md), or an equivalent existing notebook. Before a consequential decision, inspect the short source-reading task the assistant supplies.

## Understand the workflow

[WORKFLOW.md](WORKFLOW.md) describes the continuing loop: question queue, selection and scope, research and challenge, versioned release, record alignment, monitoring and reuse, continuation or revision, and retained archive branches. A project may end with a private handover; publication is optional. During research the assistant should recommend relevant questions for the queue, linking existing work that could be reused and the checks still needed. It presents a short ranked set for your decision at natural checkpoints.

[WORKING_RULES.md](WORKING_RULES.md) supplies the portable working agreement. [RESEARCH_FRAMEWORK.md](RESEARCH_FRAMEWORK.md) gives fuller guidance for the research stages. Instructions and passed scripts do not establish source truth or independent verification.

## Select the Python command

The tools use the Python standard library. Run them from this pack's directory. First identify a Python 3 interpreter available on your machine:

| Environment | First command to try | Alternative |
|---|---|---|
| Linux or macOS | `python3 --version` | `python --version`, confirming Python 3 |
| Windows | `py -3 --version` | `python --version`, confirming Python 3 |

The commands below use `python3`. Replace only that prefix with your confirmed `python` or `py -3` command when needed. Do not assume that a failed interpreter lookup is a research or checker failure. On 17 October 2026 these commands ran without errors on Windows (with `py -3` in PowerShell, and the style check and the tests also in Command Prompt), macOS and Ubuntu. If you keep the pack in a Git repository on Windows, add a `.gitattributes` file containing the line `* -text` before the first commit; otherwise Git can convert line endings, and the example's byte-for-byte check then fails.

This pack installs no hooks and changes no application permissions. If the assistant cannot execute commands, it must say so and provide the commands for you to run. Record actual results.

For a Markdown draft, run in your terminal:

```sh
python3 -B style_check.py path/to/draft.md
```

For an explicit list of Python and JSON files, run in your terminal:

```sh
python3 -B code_gate.py --json path/to/analysis.py path/to/inputs.json
```

Replace the example paths with the actual files. Unlisted files and unsupported languages remain unchecked. These scripts inspect the named inputs without executing your analysis or contacting a service.

Both return zero when their implemented checks find no blocking issue, and non-zero for a blocking finding or incomplete check. The prose checker applies a house profile: its first-person rule is inapplicable to your own account or a destination that expressly permits first person. Record that profile mismatch and the actual non-zero status; preserve the voice and do not describe the check as passed. Other findings still need their own classification. Read and classify findings before changing anything. Preserve reasons, limitations and necessary quotations. A style finding is not evidence that a research statement is wrong.

To test the supplied checkers, run in your terminal:

```sh
python3 -B -W error::ResourceWarning -m unittest discover -s tests -v
```

## Try the existing reproducible example

The example retains the public package and its own README, attribution, licence and limits. Its data are historical. It checks declared inputs, arithmetic and output agreement; it does not independently verify the original sources.

For the mechanical check, run in your terminal:

```sh
python3 -B examples/ai-infrastructure-v7.1/reproduce.py --check
```

To inspect a quantity's source, period, qualifiers and calculation context, run in your terminal:

```sh
python3 -B examples/ai-infrastructure-v7.1/reproduce.py --explain C021
```

Then open the original source linked by the explanation and inspect the stated passage. Record whether you completed that source check and any access barrier. A successful script is not a substitute.

For a changed-input demonstration on a disposable copy, run in your terminal:

```sh
python3 -B examples/ai-infrastructure-v7.1/reuse_example.py
```

Record calculation reproduction, source checking and changed-input testing separately. The supplied example remains intact.

## Try the forecast scorecard example

The second example is the unchanged public version 0.5 bundle of the AI Energy-Demand Forecast Scorecard. Its data are a frozen historical snapshot. Use Python 3.11 or newer, as its README requires.

For the mechanical check, run in your terminal:

```sh
python3 -B examples/forecast-scorecard-v0.5/reproduce.py --check
```

The [method map](examples/FORECAST_SCORECARD_METHOD_MAP.md) points to records for the seven research steps and two workflow stages, marks those not shown and gives further commands. The check does not verify source truth or the scorecard's scientific claims.

## Consider a separate review

Before relying on, submitting or publishing the result, consider the optional review in [CROSS_REVIEW.md](CROSS_REVIEW.md). It explains what to supply and how to record findings and unresolved limits. You choose the reviewer and authorise any external sharing.

## Return feedback

Complete [FEEDBACK_HUMAN.md](FEEDBACK_HUMAN.md) from your own experience, preferably before reading the assistant's account. Ask the assistant to complete [FEEDBACK_AGENT.md](FEEDBACK_AGENT.md) with evidence locators and omissions. Preserve differences between the accounts. One trial does not establish general effectiveness.

Share redacted observations after removing private work, personal data and credentials, by email to NMAIResearch@proton.me. Do not send complete transcripts or project data by default.

This public pilot edition is shared under two licences: the documents under CC BY 4.0 and the scripts (`style_check.py`, `code_gate.py` and `tests/`) under the MIT licence; see [LICENSE.md](LICENSE.md). The published examples keep their CC BY 4.0 licences, in examples/AI_INFRASTRUCTURE_LICENSE.txt and examples/FORECAST_SCORECARD_LICENSE.txt. NM AI Research supplies the original approach and tools; OpenAI GPT-6 prepared the portable pack and its revisions under the author's direction.
