# Replication and reproduction

Purpose: check a specified existing result and distinguish repeatable computation from independent evidence.

**Use when:** the task asks whether a result can be obtained again.

**Inputs:** exact source result, version, inputs, environment, procedure, expected output and a justified agreement criterion.

**Minimum procedure:**
- Define the scope: rerunning the same computation, reimplementing it, or testing the claim using new observations.
- Preserve originals and use a disposable working copy. Record unavailable inputs or instructions.
- Reproduce the stated procedure and compare against criteria selected in advance. Keep failures and deviations.
- Trace important inputs to their source passages separately from running code.
- Test a meaningful changed input where appropriate and record the expected effect before observing the output.
- Investigate disagreement before altering expected values.

**Output:** matched and unmatched results, exact commands, input/version identities, deviations and unchecked source or interpretation questions.

**Failure conditions:** editing the reference to obtain agreement; treating identical output as source verification; calling repeated calls to one model independent confirmation; hiding unavailable inputs or failed attempts.
