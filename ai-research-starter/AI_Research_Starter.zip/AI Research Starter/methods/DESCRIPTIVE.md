# Descriptive estimation

Purpose: estimate a defined quantity without forcing the question into a directional hypothesis.

**Use when:** the question asks how much, how often, where or for whom.

**Inputs:** target quantity, population, observation period, measurement definition, data source, sampling or coverage process and access limits.

**Minimum procedure:**
- Define what is counted or measured, with units and inclusion boundaries.
- Describe how observations enter the dataset and what is missing. Distinguish the target population from the observed sample.
- Inspect duplicates, missing values, incompatible definitions and changes over time.
- Choose an uncertainty treatment appropriate to the design. State assumptions; do not invent a confidence interval unsupported by the sampling process.
- Preserve inputs, extraction choices and calculations. Show sensitivity to consequential definitional or missing-data choices where feasible.
- For ratios, retain the numerator, denominator and sample size.

**Output:** an estimate or supported range with population, period, uncertainty, coverage limits and reproducible calculations. An insufficient-evidence result is permitted.

**Failure conditions:** treating a convenience sample as representative without support; concealing the denominator; averaging incomparable measures; presenting stale observations as current; inferring causation from description.
