# Deliverable assessment route

Purpose: select the existing Deliverable Filter only for a question about an announced claim and what can be delivered or observed.

**Use when:** the question concerns announced capacity, capability, cost, valuation, demand, performance or timing.

**Inputs:** the exact claim, population or system boundary, quantity and units, period, relevant commitments and practical constraints.

**Minimum procedure:** follow [DELIVERABLE_FILTER.md](../DELIVERABLE_FILTER.md), retaining evidence that supports, weakens or leaves the announcement unresolved. Normalise denominators and dates, inspect dependencies and preserve uncertainty.

**Output:** a defensible estimate or range where possible, supporting evidence, principal constraint or assumption and the observation that could change the assessment.

**Failure conditions:** presuming inflation; manufacturing a discount; applying this route to a question about measurement validity, description or replication merely because the file is available. Select another route when it answers the actual question better.
