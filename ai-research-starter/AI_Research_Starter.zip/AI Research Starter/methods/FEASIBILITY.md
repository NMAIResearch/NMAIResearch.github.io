# Needs and feasibility assessment

Purpose: test whether a proposed project or product addresses a concrete need and can be evaluated within available resources.

**Use when:** the task concerns a useful research project, tool, workflow or business opportunity.

**Inputs:** intended user and task, current alternatives, proposed benefit, accessible users or evidence, resources, dependencies and constraints.

**Minimum procedure:**
- Describe the problem and current workaround. Separate observed need from an assumed market.
- Use IDEACHECK.md where novelty matters. An existing solution may meet the need.
- Distinguish technical feasibility, measurement validity, user benefit, adoption and commercial viability. Evidence for one does not establish the others.
- Identify the dependency or assumption most likely to prevent a useful result. Check access before promising a build.
- Propose the smallest informative test with a relevant baseline, observable outcome, resource bound and inconclusive condition.
- Obtain approval for participant contact, collection, spending or material scope changes. Preserve contrary feedback and unsuccessful tests.

**Output:** a bounded opportunity or feasibility assessment, current alternatives, unresolved dependencies and an agreed next test.

**Failure conditions:** treating a literature gap as demand; treating a demonstration as deployment evidence; relying on inaccessible data; committing resources before validating the central assumption; asserting willingness to pay from the agent's judgement.
