# Evidence review and mapping

Purpose: organise accessible evidence around a defined question while preserving disagreements and search limits.

**Use when:** the task asks what is known, disputed, missing or worth investigating. An initial evidence map may help define a later review.

**Inputs:** question, population or setting, concepts, period, available search sources, inclusion and exclusion criteria, time and access constraints. Locate suitable disciplinary guidance before claiming a formal review type.

**Minimum procedure:**
- Record search sources, date, exact queries and terminology variants. Check that the search can recover a known relevant example where available.
- Retain included sources, important exclusions and access failures. Distinguish full text, abstracts, snippets and leads.
- Extract the design, population, measurement, result, uncertainty and limitations relevant to each claim.
- Compare like with like. Record contradictory results, source dependence and differences that prevent combination.
- Give the user decisive passages to read before changing the project's direction.

**Output:** a bounded evidence map or synthesis, a claim record, disagreements, missing evidence and justified next work.

**Failure conditions:** calling a limited search exhaustive; treating missing retrieval as absence; combining incompatible results; using a review checklist as proof of methodological quality; claiming systematic-review status without an appropriate protocol and execution record.

**Example question:** what evidence supports a proposed measurement in the intended setting, and what remains untested? This asks about the evidence found, not whether an entire field has no evidence.
