# Comparison and causal questions

Purpose: distinguish a fair performance comparison from a claim that an intervention caused an outcome.

**Use when:** the question asks whether one approach performs better, or whether an intervention produces a change.

**Inputs:** alternatives, intended task or population, outcome, available design, comparison condition, resource allowance and decision criteria. Use appropriate domain guidance for a causal claim.

**Minimum procedure:**
- State whether the aim is prediction, descriptive comparison or causal estimation. Name the comparison that would answer it.
- Include a simple relevant baseline. Match tasks, data access and resources, or explain unavoidable differences.
- Choose outcomes, evaluation data, uncertainty treatment and decision rules before inspecting final results. Retain an inconclusive outcome.
- Separate development from evaluation and inspect leakage, selection, missingness and repeated tuning.
- For causal claims, state the assumptions and rival explanations the design can or cannot address. A before-and-after difference alone does not isolate an intervention.
- Report the actual difference, uncertainty, adverse results and resource use where measured. Do not infer an effect from separate significance labels.

**Output:** a bounded comparative finding, its baseline, uncertainty, assumptions and remaining alternative explanations.

**Failure conditions:** absent or unsuitable comparison; unequal conditions hidden from the reader; interpreting predictive accuracy as treatment benefit; presenting correlation as causation; selecting a favourable metric after seeing results.
