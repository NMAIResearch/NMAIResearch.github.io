# Measurement assessment

Purpose: examine whether a proposed measure supports the intended interpretation and use.

**Use when:** a score, proxy, classifier or questionnaire is proposed as a measure of an outcome.

**Inputs:** intended construct, population and setting, unit of analysis, proposed use, candidate measure, reference measures and accessible validation evidence. Consult authoritative guidance for the measurement domain.

**Minimum procedure:**
- Separate the desired outcome from the available score. State the interpretation that must be justified.
- Examine how the construct and reference measure were defined. Record whether the reference itself has limitations for this use.
- Distinguish association, agreement, repeatability, prediction and sensitivity to change. Record which was actually examined.
- Match evidence to the intended population, setting and individual or group use. Examine subgroup limitations, data leakage and evaluation independence where relevant.
- For change over time, seek evidence about within-person measurement and error over repeated observations. Do not infer it solely from cross-sectional accuracy or an average prediction error.
- Keep validation of a measure separate from evidence that acting on it improves outcomes.

**Output:** an interpretation-by-evidence table: supported use, partially supported use, unresolved use, supporting passage and required next check.

**Failure conditions:** substituting a related construct; treating correlation as agreement; claiming individual change detection from group-level association; transferring validity across populations without support; inventing a universal error threshold.

**Example question:** does a proposed score track the intended outcome in the same people over time, compared with a suitable reference?
