# Research working rules

Purpose: provide a short portable working agreement for the user and assistant using this pack.

Status: candidate for review. Adopt it explicitly for the project. It supplies no installed hooks, automatic enforcement or authority over platform permissions, institutional or organisational requirements or the user's decisions.

- **At the start:** explain the process, the proposed output and what the user will need to decide or read. Ask only what is needed for a consequential choice.
- **Before substantial research:** state the question, intended use, population or setting, outcome, accessible evidence, resources and stopping point. Use METHOD_SELECTION.md. If definitions remain open, label the work exploratory and preserve the competing definitions.
- **Before changing scope or method:** show the proposed change, reason, alternative and effect. Obtain the user's agreement. Keep the earlier plan and a dated decision note.
- **Before making a consequential claim:** inspect its source passage and record access, location, relevant definitions and limitations. Separate observation, calculation and inference. State who assessed support. Preserve permitted source copies; a hash confirms bytes, not truth.
- **When access is limited:** label abstract-only evidence, search leads and generated summaries. Quote only wording checked against the original. Report what was not found within the actual search; do not infer universal absence.
- **Before recommending a direction:** review the assumption it depends on, contrary evidence, missing evidence and whether the conclusion exceeds the search. Self-review remains self-review. Preserve uncertainty in chat as well as files.
- **At a consequential decision:** give the user a short source-reading task: the decisive claim, exact passage, reason to inspect it and what the result could change. Record checks as completed only when observed or reported, with that distinction.
- **When a check fails:** retain its output and classify the finding before editing. Correct a real defect, name a false positive, or preserve the substance in a rewrite. Do not remove limitations, weaken tests or bypass a failure to obtain a pass.
- **Before overwriting or discarding work:** inspect the exact target, preserve the original evidence and confirm any destructive effect with the user. Keep changes recoverable and avoid concurrent writers.
- **Before submission, publication, external transmission or new spending:** show the exact destination, material and effect and obtain approval. Remove secrets and unintended private information. Ordinary research within the agreed scope does not require repeated approval.
- **When research exposes a useful follow-up:** recommend a question for the queue, explain its relevance and evidence, link reusable work and identify what needs rechecking. Check for duplicates. Present candidates at natural checkpoints and let the user select priorities; a queue entry does not authorise starting another project.
- **When reporting AI assistance:** encourage a brief, fair note of the help actually used and any relevant conflict, following AI_DISCLOSURE.md and the actual destination requirements. Once accurate wording is agreed, use it and continue. Reopen only for a material factual or requirement change; do not turn contribution wording into repeated negotiation about credit.
- **At handover:** answer the question within the evidence's scope. List what was completed, reproduced, independently reviewed and left unchecked. Include the next decision and separate human and agent feedback. Where a separate assessment would help, recommend CROSS_REVIEW.md and leave the reviewer and sharing decision with the user.

Use a single project notebook when that is enough. Add files or formal controls only when they improve inspection, recovery or reproduction. Following these instructions does not demonstrate research validity or measured improvement.
