# Forecast scorecard: method map

This example is version 0.5 of the AI Energy-Demand Forecast Scorecard, [Zenodo record 23434495](https://zenodo.org/records/23434495), DOI [10.5281/zenodo.23434495](https://doi.org/10.5281/zenodo.23434495). NM AI Research material is CC BY 4.0; third-party material retains its own rights (bundle PAPER.md, Licence). The data are a frozen historical snapshot (bundle PAPER.md, Reproducibility). The licence copy is [FORECAST_SCORECARD_LICENSE.txt](FORECAST_SCORECARD_LICENSE.txt).

## Where to inspect each step

Kit locators refer to files in the kit's top folder. Bundle locators refer to files in [forecast-scorecard-v0.5/](forecast-scorecard-v0.5/). Each row identifies material to inspect, without certifying that the whole step was performed.

| Kit step | Kit locator | Bundle locator | What can be inspected |
|---|---|---|---|
| 1. Question | RESEARCH_FRAMEWORK.md, 1. Question | PAPER.md, The question and why it matters | The descriptive questions and their boundaries. |
| 2. Scope and method | RESEARCH_FRAMEWORK.md, 2. Scope and method | CANDIDATE_OBSERVATIONS.json, selection_rule; OBSERVATIONS.json, scope_limits | Selection rules, choices settled after retrieval and scope limits. A complete pre-outcome plan is not supplied. |
| 3. Novelty and usefulness | RESEARCH_FRAMEWORK.md, 3. Novelty and usefulness | PAPER.md, Earlier work; PRIOR_WORK.json, sources and four_e_comparison | Earlier work and the stated extension are described. This is not a demonstration of novelty or usefulness. |
| 4. Source evidence | RESEARCH_FRAMEWORK.md, 4. Source evidence | SOURCE_CATALOGUE.json, sources[].url, sources[].locator, sources[].original_sha256 and sources[].coverage_limit | Source references, locators, retained-original digests and inspection limits. The originals are excluded from the bundle (PAPER.md, Verification). |
| 5. Analysis | RESEARCH_FRAMEWORK.md, 5. Analysis | PAPER.md, Method; RESULTS.json, comparisons and like_for_like_comparison | Calculation rules, comparison records and grouped output. No forecast-quality or model-performance baseline was run (PAPER.md, Limits). |
| 6. Challenge and revision | RESEARCH_FRAMEWORK.md, 6. Challenge and revision | SUPPORT_REVIEW.json, reviews[].verdict and reviews[].reason; PAPER.md, Verification | Recorded support verdicts and reasons, with the paper's account of checks and their limits. This is not fresh source review. |
| 7. Publication and maintenance | RESEARCH_FRAMEWORK.md, 7. Publication and maintenance | README.md, opening command blocks; PAPER.md, Licence and AI assistance, conflicts and limitations | Run instructions, licence and disclosure. Not shown in this bundle: a maintenance log. |
| Align records | WORKFLOW.md, stage table, Align records | Not shown in this bundle | A package manifest is available (REPRODUCTION.json, files), but a cross-location release comparison is not supplied. |
| Monitor and reuse | WORKFLOW.md, stage table, Monitor and reuse | Not shown in this bundle | The worked demonstration is documented (README.md, reuse_example.py command). It does not establish post-release monitoring or actual reuse. |

## Commands to try

The bundle README.md documents these commands. Python 3.11 or newer is required (bundle README.md, opening instructions). From the kit's top folder, run in your terminal:

```sh
python3 -B examples/forecast-scorecard-v0.5/reproduce.py --check
python3 -B examples/forecast-scorecard-v0.5/reproduce.py --explain O12
python3 -B examples/forecast-scorecard-v0.5/reproduce.py --compare O11 O12
python3 -B examples/forecast-scorecard-v0.5/reproduce.py --paper-blocks
python3 -B examples/forecast-scorecard-v0.5/reuse_example.py
python3 -B examples/forecast-scorecard-v0.5/test_reproduce.py -v
python3 -B examples/forecast-scorecard-v0.5/reproduce.py --output-dir ../forecast-regenerated
```

The comparison's `not_comparable` state is intended (bundle README.md, comparison paragraph). Run from the kit's top folder, the final command creates `../forecast-regenerated`, a directory outside the kit, and refuses an existing destination (bundle README.md, output-directory paragraph).

## Limits

The map points to where steps can be inspected. It is not evidence that the kit was used to make the scorecard, that the scorecard's findings are right, or that the kit improves research quality. The mechanical check does not verify source truth, rebuild provider models or accept scientific claims (bundle README.md, check paragraph).
