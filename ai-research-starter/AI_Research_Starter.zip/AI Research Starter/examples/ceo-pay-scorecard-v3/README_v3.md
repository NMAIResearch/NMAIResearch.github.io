# CEO Pay-vs-Delivery Scorecard: v3 S&P 500 edition

**Author:** NM AI Research. **ORCID:** 0009-0003-4213-7769. **Date:** 2026-11-06. **Licence:** CC BY 4.0, except `universe_sp500.txt`, which is CC BY-SA 4.0.

This work was produced through an AI-assisted workflow directed and reviewed by the author.

## Scope

The dated universe contains 503 constituent securities. The frozen SEC Pay Versus Performance spine contains 2,769 populated company-year rows for 498 securities and five explicit placeholders. Alphabet, Fox and News Corp dual classes are collapsed by SEC CIK, producing 495 issuer rows. Of those, 493 contain both company and peer TSR.

The target layer is separate. It contains 29 original S&P 100 Layer A cases and 18 S&P 500 findings extensions. All 47 rows were checked against exact SEC filings. The percentages cover different cash and equity measures and are not a common cross-company metric.

The constituent list is a dated Wikipedia snapshot, not an official S&P DJI list. Compensation Actually Paid is an SEC fair-value remeasurement, not cash received. The analysis is descriptive and does not attribute TSR to a CEO.

## Headline measurements

- 227 of 493 TSR-comparable issuers beat their disclosed peer index over the available reporting window: 46.0%. The numerator is 227, the denominator is 493 and N is 493. The 50% figure, 4.0 percentage points higher, is an arithmetic reference, not a chance level. No statistical baseline or hypothesis test was run.
- Median latest-year granted compensation is $17.84 million across 493 available values. The S&P 100 v0.3 median was $28.37 million across 98 company rows. The v3 median is $10.53 million lower, or 37.1% below the S&P 100 value.
- 88 of 493 TSR-comparable issuers report a company TSR index below 100 over the available window: 17.8%.
- 34 of 495 issuers report negative latest-year Compensation Actually Paid: 6.9%.
- 36 of 493 TSR-comparable issuers are at or above the inclusive upper quartile of available-window CAP and below their disclosed peer index: 7.3%.
- Reporting-window coverage is 478 rows with five fiscal-year labels, eight with four, three with three, three with two, two with one and one with six. The spine labels a fiscal year by the calendar year in which it ended, except that SNA's and SWK's corrected fiscal 2021 rows keep the table's year, 2021, where that rule would give 2022.

## Deposit files

| File | Purpose |
|---|---|
| `findings_v3.md` | Findings, method, guardrails, verification and disclosure |
| `CEO Pay-vs-Delivery Scorecard_ v3 findings (S&P 500).pdf` | Rendered findings, added at the mint stage |
| `README_v3.md` | Bundle guide |
| `pvp_pulled.csv` | Frozen SEC Pay Versus Performance spine, including five explicit placeholders |
| `scorecard_sp500.csv` | Issuer-level view with explicit window bounds and source accessions |
| `board_targets.csv` | Forty-seven audited board-target cases with exact primary-source metadata |
| `ceo_pay_data.csv` | Nineteen primary-verified CEO-name backfills |
| `assemble_sp500.py` | Deterministic issuer-level aggregation from the three CSV inputs, validated against `universe_sp500.txt` |
| `CEO_Pay_Scorecard_v3_interactive.html` | Frozen sortable view of `scorecard_sp500.csv` |
| `sources_v3.csv` | Source register, support limits, retained-original digests and locators |
| `evidence/2026-10-17/sec-tsla-0001104659-25-090866_R2_injected-script-removed.htm` | TSLA Pay vs Performance page from the SEC filing, saved with one injected script removed |
| `evidence/2026-10-17/sec-tsla-0001104659-25-090866_R2_text.txt` | Text extraction of that page |
| `universe_sp500.txt` | Dated 503-security snapshot with stable source revision, modification notice and CC BY-SA 4.0 attribution |

The deposit excludes other source extracts, migration scripts, build notes and review trails. The two TSLA files above are its only evidence files; `sources_v3.csv` gives their digests and the SHA-256 digest of each cited source's saved original.

## Licence and source boundary

The findings, README, data, code and interactive are licensed CC BY 4.0. `universe_sp500.txt` is an adapted list from Wikipedia revision 1364118843 and is licensed separately under CC BY-SA 4.0. The Zenodo record therefore uses the mixed-licence category `Other (Open)` rather than applying CC BY 4.0 to every file.

No BlackRock holdings file or S&P factsheet is included, redistributed or required for reproduction. This independent work is not sponsored, endorsed or reviewed by BlackRock or S&P Dow Jones Indices.

The two TSLA evidence files are copies of a page from a public SEC filing and are not covered by this deposit's CC BY 4.0 licence. The AFL-CIO Executive Paywatch pages are AFL-CIO's own publications and are not redistributed: the findings quote short passages from them with attribution, and `sources_v3.csv` gives their links and the digests of the saved copies.

## Reproduce the issuer view

Run in your terminal from the extracted bundle:

```sh
python3 assemble_sp500.py
```

The script uses only the Python standard library. The bundle does not contain a self-contained full-universe EDGAR repull script.

## Guardrails

- TSR is not caused by the CEO. Macro conditions, sector exposure, predecessor decisions and luck also affect it.
- The peer benchmark is selected or disclosed by the issuer. Its composition affects the gap.
- The 47-case target layer is non-random and mixes different incentive measures.
- S&P 500 membership is secondary-source and dated. Index membership changes.
- Survivorship: the universe is the constituent list of one dated snapshot. Companies that were in the index during a reporting window but are not in the snapshot are absent, and companies that joined the index during their window are included. The effect of this selection on the counts and shares was not measured.
- `Realised` is shorthand for Compensation Actually Paid. It is not cash received.
- The analysis is descriptive and is not investment advice.

## Verification

- TSLA FY2024 comes from accession `0001104659-25-090866`, with CAP's dash read as nil and a `MANUAL_PRIMARY_TABLE` flag. The repaired source window is 2020 to 2024. Paywatch's published figures and four exclusion wordings are attributed to its retained page; which exclusion applies remains unassessed. `sources_v3.csv` records these support boundaries.
- SNA's and SWK's fiscal 2021 rows come from their 2026 proxies, accessions `0000091440-26-000101` and `0001140361-26-008170`, labelled 2021 and flagged `MANUAL_PRIMARY_TABLE`: each had shared the label 2022 with fiscal 2022 and carried its return and net income. Of the windows short of five labels, AVY, CDNS, JNJ, KVUE and TDY have more rows than labels, and their filings were not read for this.
- `scorecard_sp500.csv` carries the exact SEC accession or accessions used for each issuer. `assemble_sp500.py` derives the headline counts and distribution statistics from those rows.
- All 47 `board_targets.csv` rows have `PRIMARY_VERIFIED` status and carry exact accession, form, primary document, filing date, period, value basis and source locator.
- All 19 `ceo_pay_data.csv` rows have `PRIMARY_VERIFIED` status and accession-level source metadata.
- The primary recoveries are Intel `0000050863-26-000066`, Erie `0001193125-26-116761`, American Tower `0001053507-26-000088` and Synchrony `0001601712-26-000017`.
- Welltower's grant structure and thresholds were checked against DEF 14A accession `0000766704-26-000014`, filed 2026-04-10; `board_targets.csv` names its primary document.
- The membership list is the secondary 2026-07-16 snapshot described at the top of `universe_sp500.txt`.
- The S&P 100 comparison uses the published v0.3 frozen scorecard: 46/96 TSR-comparable company rows and a $28,367,679.50 median latest-year grant across 98 company rows.
- No statistical baseline, hypothesis test or causal model was run.

The consolidated version history is in `findings_v3.md`, under Version history (for reference).

## AI assistance, conflicts and limitations

The research design, method, sourcing decisions and analytical judgements are
the author's. Anthropic Opus 5.5 assisted with scope, source checks and the
review of this version. OpenAI GPT-6.1 Sol drafted this version's changes, and
Anthropic Opus 5.5 drafted the corrections made after them, so this text was
artificially generated and was reviewed by the author before publication. Both
ran as command-line agents working on local files. Moonshot Kimi K3.1 Pro, also
run as a command-line agent, independently reviewed the Tesla rows and the
counts that changed with them, and Google Gemini 4 Argon High, run the same way,
reviewed those rows again with the rows corrected since and the texts. The
assisting and reviewing models are not always neutral parties to the subject
matter: Anthropic, OpenAI, Moonshot and Google supply AI models and compete with
some issuers' AI products, and Google's parent, Alphabet, is an issuer in this
dataset. These are potential conflicts, not evidence that any result is wrong.

The author holds no direct position in any company named. A workplace
defined-contribution pension may hold some names indirectly through pooled funds
not directed by the author. No third party funded or directed the work.

Guarantee: every measured claim is traced to the primary document named in the
Verification note. assemble_sp500.py regenerates scorecard_sp500.csv from
pvp_pulled.csv, ceo_pay_data.csv and board_targets.csv, and validates inputs
against universe_sp500.txt. The Paywatch table transcribes the retained
publication; it does not recalculate its underlying pay data. Modelled or
estimated inputs are identified as such in the Verification note rather than
presented as measurements. A reader can check this without trusting either party.

What the author cannot guarantee: a language model's output can be wrong in ways
that survive review. In prose the error is locally plausible and consistent in
tone with what surrounds it; in code it simply runs, and a wrong constant or a
mis-set filter still returns a clean number. Several methods have been deployed to
mitigate this, including explicit instructions, internal red-teaming and
cross-lab blindspot checks, but the author does not claim the review is
exhaustive. Corrections are logged against the DOI when surfaced.

No warranty is offered beyond the terms of the CC BY 4.0 licence.
The CC BY-SA 4.0 terms apply to `universe_sp500.txt`. Independent analysis and
open-science documentation only, not investment advice.

## Version history (for reference)

The eight v3 changes are listed in `findings_v3.md`. v2.2's assisting models were Anthropic Opus 4.8 and OpenAI GPT-5.6 Sol.
