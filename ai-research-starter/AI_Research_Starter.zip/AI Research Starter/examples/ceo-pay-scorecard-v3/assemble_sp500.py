#!/usr/bin/env python3
"""Build one issuer-level pay-versus-delivery view from the SEC PvP spine.

Dual share classes are collapsed by SEC CIK. Reporting-window bounds are
carried explicitly because the available PvP history is not uniformly five
fiscal years. Board-target fields are joined only for the audited 47-case
layer and remain labelled by metric type.

The script reads pvp_pulled.csv, ceo_pay_data.csv and board_targets.csv, and
validates the input security set against universe_sp500.txt. It writes
scorecard_sp500.csv.

Anthropic Opus 4.8 and OpenAI GPT-5.6 Sol assisted with the bundle containing
this script. The generated measurements remain traceable to SEC accessions.
"""
import csv
import os
import statistics
from collections import defaultdict
from pathlib import Path


PREFERRED_TICKER = {
    "0001652044": "GOOGL",
    "0001754301": "FOXA",
    "0001564708": "NWSA",
}


def num(value):
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None


def issuer_fact_key(row):
    return tuple((key, value) for key, value in row.items() if key != "ticker")


rows = list(csv.DictReader(open("pvp_pulled.csv")))
universe = [
    line.strip()
    for line in Path("universe_sp500.txt").read_text().splitlines()
    if line.strip() and not line.startswith("#")
]
spine_tickers = {row["ticker"] for row in rows}
resolved_tickers = {
    ticker
    for ticker in spine_tickers
    if any(row["fiscal_year"] for row in rows if row["ticker"] == ticker)
}
placeholder_tickers = spine_tickers - resolved_tickers
if len(universe) != 503 or len(set(universe)) != 503:
    raise SystemExit("universe_sp500.txt must contain 503 unique securities")
if spine_tickers != set(universe):
    missing = sorted(set(universe) - spine_tickers)
    extra = sorted(spine_tickers - set(universe))
    raise SystemExit(f"spine/universe mismatch: missing={missing}; extra={extra}")
if len(resolved_tickers) != 498 or len(placeholder_tickers) != 5:
    raise SystemExit(
        "expected 498 resolved securities and five placeholders; "
        f"found {len(resolved_tickers)} and {len(placeholder_tickers)}"
    )

namemap = {}
if os.path.exists("ceo_pay_data.csv"):
    namemap = {
        row["ticker"]: row["peo_name"]
        for row in csv.DictReader(open("ceo_pay_data.csv"))
        if row.get("peo_name")
    }

boardmap = {}
if os.path.exists("board_targets.csv"):
    boardmap = {
        row["ticker"]: row for row in csv.DictReader(open("board_targets.csv"))
    }

by_issuer = defaultdict(list)
for row in rows:
    by_issuer[row["cik"].zfill(10)].append(row)

output = []
for cik, issuer_rows in by_issuer.items():
    tickers = sorted({row["ticker"] for row in issuer_rows})
    ticker = PREFERRED_TICKER.get(cik, tickers[0])
    unique = {issuer_fact_key(row): row for row in issuer_rows}
    data = [row for row in unique.values() if row["fiscal_year"]]
    if not data:
        continue

    fiscal_years = sorted({int(row["fiscal_year"]) for row in data})
    latest_fy = fiscal_years[-1]
    latest_rows = [row for row in data if int(row["fiscal_year"]) == latest_fy]
    latest = max(
        latest_rows,
        key=lambda row: num(row["peo_total_comp_usd"])
        or num(row["comp_actually_paid_usd"])
        or 0,
    )

    window_cap = sum(num(row["comp_actually_paid_usd"]) or 0 for row in data)
    window_grant = sum(num(row["peo_total_comp_usd"]) or 0 for row in data)
    company_tsr = num(latest["company_tsr_idx"])
    peer_tsr = num(latest["peer_tsr_idx"])
    gap = (
        company_tsr - peer_tsr
        if company_tsr is not None and peer_tsr is not None
        else None
    )
    latest_grant = num(latest["peo_total_comp_usd"])
    latest_cap = num(latest["comp_actually_paid_usd"])
    target = next((boardmap[item] for item in tickers if item in boardmap), None)

    output.append(
        {
            "ticker": ticker,
            "issuer_cik": cik,
            "share_class_tickers": ";".join(tickers),
            "window_start_fy": fiscal_years[0],
            "window_end_fy": fiscal_years[-1],
            "window_year_count": len(fiscal_years),
            "latest_fy": latest_fy,
            "latest_ceo": latest["peo_name"]
            or namemap.get(ticker, "")
            or next((namemap[item] for item in tickers if item in namemap), "")
            or (target["peo_name"] if target else ""),
            "latest_granted_usd": int(latest_grant) if latest_grant is not None else "",
            "latest_cap_usd": int(latest_cap) if latest_cap is not None else "",
            "window_granted_usd": int(window_grant),
            "window_cap_usd": int(window_cap),
            "company_tsr_idx": latest["company_tsr_idx"],
            "peer_tsr_idx": latest["peer_tsr_idx"],
            "tsr_vs_peer": round(gap, 1) if gap is not None else "",
            "beat_peers": "" if gap is None else gap > 0,
            "cap_to_granted_x": (
                round(latest_cap / latest_grant, 2)
                if latest_grant not in (None, 0) and latest_cap is not None
                else ""
            ),
            "board_target_in_scope": bool(target),
            "board_target_stratum": target["coverage_stratum"] if target else "",
            "board_target_featured_pct": (
                target["incentive_target_payout_pct"] if target else ""
            ),
            "board_target_metric_type": target["payout_metric_type"] if target else "",
            "board_target_verification": (
                target["verification_status"] if target else ""
            ),
            "source_accessions": ";".join(
                sorted({row["source_accession"] for row in data})
            ),
            "flags": ";".join(
                sorted({row["flag"] for row in issuer_rows if row["flag"]})
            ),
        }
    )

columns = [
    "ticker",
    "issuer_cik",
    "share_class_tickers",
    "window_start_fy",
    "window_end_fy",
    "window_year_count",
    "latest_fy",
    "latest_ceo",
    "latest_granted_usd",
    "latest_cap_usd",
    "window_granted_usd",
    "window_cap_usd",
    "company_tsr_idx",
    "peer_tsr_idx",
    "tsr_vs_peer",
    "beat_peers",
    "cap_to_granted_x",
    "board_target_in_scope",
    "board_target_stratum",
    "board_target_featured_pct",
    "board_target_metric_type",
    "board_target_verification",
    "source_accessions",
    "flags",
]
with open("scorecard_sp500.csv", "w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=columns)
    writer.writeheader()
    writer.writerows(sorted(output, key=lambda row: -row["window_cap_usd"]))


MILLION = 1e6


def money(value):
    return f"${value / MILLION:,.1f}M"


comparable = [row for row in output if row["tsr_vs_peer"] != ""]
latest_grants = [
    row["latest_granted_usd"] for row in output if row["latest_granted_usd"] != ""
]
beat = sum(row["beat_peers"] is True for row in comparable)
below_100 = sum(num(row["company_tsr_idx"]) < 100 for row in comparable)
negative_cap = sum(
    row["latest_cap_usd"] != "" and row["latest_cap_usd"] < 0 for row in output
)

print(f"issuers in view: {len(output)}  (TSR-comparable: {len(comparable)})")
print(
    f"universe securities: {len(universe)}  "
    f"(resolved: {len(resolved_tickers)}; placeholders: {len(placeholder_tickers)})"
)
print("placeholder securities:", ", ".join(sorted(placeholder_tickers)))
if latest_grants:
    quartiles = statistics.quantiles(latest_grants, n=4, method="inclusive")
    print(f"median latest-year granted: {money(statistics.median(latest_grants))}")
    print(f"mean latest-year granted: {money(statistics.mean(latest_grants))}")
    print(f"latest-year granted p25/p75: {money(quartiles[0])} / {money(quartiles[2])}")
print(
    f"beat own disclosed peer index over available reporting window: "
    f"{beat}/{len(comparable)} ({100 * beat / len(comparable):.1f}%)"
)
print(
    f"company TSR index below 100: {below_100}/{len(comparable)} "
    f"({100 * below_100 / len(comparable):.1f}%)"
)
print(f"negative latest-year CAP: {negative_cap}")
print(f"board-target cases joined: {sum(row['board_target_in_scope'] for row in output)}")

flags = defaultdict(int)
for row in output:
    for flag in row["flags"].split(";"):
        if flag:
            flags[flag] += 1
if flags:
    print("flags present:", ", ".join(f"{key}={value}" for key, value in sorted(flags.items())))

print("\n== Top 12 by reporting-window CAP ==")
for row in sorted(output, key=lambda item: -item["window_cap_usd"])[:12]:
    print(
        f"  {row['ticker']:6} {money(row['window_cap_usd']):>11}  "
        f"granted={money(row['window_granted_usd']):>10}  "
        f"window={row['window_start_fy']}-{row['window_end_fy']}  flags={row['flags']}"
    )

print("\n== Top-quartile reporting-window CAP and lagged own peer group ==")
caps = [row["window_cap_usd"] for row in comparable]
threshold = statistics.quantiles(caps, n=4, method="inclusive")[2]
gap_cases = [
    row
    for row in comparable
    if row["window_cap_usd"] >= threshold and row["beat_peers"] is False
]
print(f"  threshold={money(threshold)}; cases={len(gap_cases)}")
for row in sorted(gap_cases, key=lambda item: -item["window_cap_usd"])[:15]:
    print(
        f"  {row['ticker']:6} CAP={money(row['window_cap_usd']):>11}  "
        f"TSR {row['company_tsr_idx']} vs peer {row['peer_tsr_idx']} "
        f"(gap {row['tsr_vs_peer']})"
    )
