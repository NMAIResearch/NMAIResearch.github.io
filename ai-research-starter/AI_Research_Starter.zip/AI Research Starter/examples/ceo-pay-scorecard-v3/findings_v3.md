# CEO Pay-vs-Delivery Scorecard: v3 findings (S&P 500)

**Date:** 2026-11-06. Author: NM AI Research. ORCID: 0009-0003-4213-7769. Licence: CC BY 4.0, except `universe_sp500.txt`, which is CC BY-SA 4.0.

This work was produced through an AI-assisted workflow directed and reviewed by the author.

**Scope.** The dated universe contains 503 constituent securities. The SEC Pay Versus Performance spine contains 2,769 populated company-year rows for 498 securities and five explicit placeholders. Collapsing Alphabet, Fox and News Corp dual classes by SEC CIK produces 495 issuer rows, of which 493 contain both company and peer total shareholder return. A separately audited board-target layer contains the original 29 S&P 100 cases and 18 named S&P 500 extensions.

**Interpretive limits.** S&P 500 membership comes from a dated, crowd-maintained Wikipedia snapshot, not an official S&P DJI constituent file. Compensation Actually Paid is an accounting fair-value remeasurement, not cash received. The board-target percentages cover different cash and equity programmes and are not a common cross-company measure.

No overpaid verdict is issued. The tables place disclosed pay measures beside issuer-selected peer benchmarks. They do not establish that a CEO caused the return. Naming a company or CEO here alleges nothing.

## F1: The pay ranking depends on the measure

The latest-year ranking differs from the available-window Compensation Actually Paid ranking. The latest-year table contains the Summary Compensation Table total and the SEC Compensation Actually Paid figure.

| Issuer | Latest FY | Granted | CAP | Company TSR minus peer |
|---|---:|---:|---:|---:|
| Welltower | 2025 | $821.1M | $999.6M | +190.4 |
| CrowdStrike | 2026 | $247.6M | $330.3M | -51.9 |
| Broadcom | 2025 | $205.3M | $2,267.5M | +939.0 |
| Warner Bros. Discovery | 2025 | $165.0M | $636.1M | -132.0 |
| Goldman Sachs | 2025 | $118.9M | $309.8M | +172.0 |
| Palo Alto Networks | 2025 | $99.7M | $267.5M | +126.4 |
| Microsoft | 2025 | $96.5M | $131.1M | -21.0 |
| Citigroup | 2025 | $95.8M | $144.8M | +22.9 |
| Wells Fargo | 2025 | $94.5M | $136.2M | +151.0 |
| Intel | 2025 | $93.0M | $161.6M | -179.8 |
| BNY | 2025 | $83.5M | $118.0M | +112.4 |

Welltower reported $821,090,355 in Summary Compensation Table total compensation and $999,622,730 in Compensation Actually Paid for 2025. Its filing reports about $1.3 million salary, $6.5 million non-equity incentive compensation and $813.2 million stock awards. Half of the special equity award is time-based and redeemable monthly from October 2030 to September 2035. The performance half uses market-capitalisation growth and relative TSR. The target market-capitalisation increase is $80 billion from a $119.534 billion baseline, or 66.9%; the maximum is a $100 billion increase, or 83.7%. These conditions are in Welltower's DEF 14A, accession `0000766704-26-000014`.

Robinhood reported $796.1 million granted in 2021. The Trade Desk reported $835.0 million granted in 2021. Those awards appear in the reporting-window totals rather than the latest-year ranking.

| Issuer | Available-window CAP | Window |
|---|---:|---:|
| Tesla | $49,735.0M | 2020-2024 |
| Palantir | $16,382.8M | 2021-2025 |
| Broadcom | $4,319.5M | 2021-2025 |
| Coinbase | $1,998.4M | 2021-2025 |
| Robinhood | $1,241.1M | 2021-2025 |
| Welltower | $1,175.9M | 2021-2025 |
| Palo Alto Networks | $1,067.4M | 2021-2025 |
| Alphabet | $1,047.9M | 2021-2025 |
| Oracle | $1,039.8M | 2021-2025 |
| Nvidia | $841.9M | 2022-2026 |
| Apple | $824.7M | 2021-2025 |
| Warner Bros. Discovery | $824.3M | 2021-2025 |

Tesla's available-window CAP is $49.735 billion across 2020-2024, with FY2024 CAP read as nil from the filing's dash. Five of these 12 issuers were absent from the original S&P 100 layer: Coinbase, Robinhood, Welltower, Palo Alto Networks and Warner Bros. Discovery.

## F2: High available-window CAP can coincide with a peer lag

The inclusive upper-quartile threshold for available-window CAP is $183.0 million among the 493 TSR-comparable issuers. Thirty-six of 493 issuers, 7.3%, are both at or above that threshold and below their disclosed peer index. The table lists all 36, largest available-window CAP first.

| Issuer | Window | Available-window CAP | Company TSR | Peer TSR | Gap |
|---|---:|---:|---:|---:|---:|
| Coinbase | 2021-2025 | $1,998.4M | 69 | 209 | -140.0 |
| Apple | 2021-2025 | $824.7M | 233.88 | 279.51 | -45.6 |
| Warner Bros. Discovery | 2021-2025 | $824.3M | 96 | 228 | -132.0 |
| CrowdStrike | 2022-2026 | $745.8M | 204.54 | 256.43 | -51.9 |
| The Trade Desk | 2021-2025 | $605.2M | 47.39 | 137.99 | -90.6 |
| Microsoft | 2021-2025 | $591.6M | 255 | 276 | -21.0 |
| Cadence Design Systems | 2022-2025 | $368.0M | 229 | 258 | -29.0 |
| Regeneron Pharmaceuticals | 2021-2025 | $364.9M | 159.77 | 200.89 | -41.1 |
| ServiceNow | 2021-2025 | $363.3M | 139 | 227 | -88.0 |
| Moderna | 2021-2025 | $352.9M | 28 | 120 | -92.0 |
| AMD | 2021-2025 | $346.2M | 234 | 547 | -313.0 |
| Lennar | 2021-2025 | $342.7M | 201.13 | 232.34 | -31.2 |
| Workday | 2022-2026 | $302.2M | 77 | 125 | -48.0 |
| Flex | 2022-2026 | $291.3M | 491 | 718 | -227.0 |
| Aon | 2021-2025 | $275.4M | 174 | 203 | -29.0 |
| Motorola Solutions | 2021-2025 | $274.7M | 239.54 | 241.63 | -2.1 |
| Intuit | 2021-2025 | $259.4M | 264.44 | 268.74 | -4.3 |
| Visa | 2021-2025 | $253.1M | 176.94 | 245.77 | -68.8 |
| Uber | 2021-2025 | $245.8M | 160.22 | 258.38 | -98.2 |
| Marvell Technology | 2022-2026 | $243.9M | 156.47 | 293.24 | -136.8 |
| Intel | 2021-2025 | $240.3M | 85.08 | 264.83 | -179.8 |
| Chubb Limited | 2021-2025 | $235.7M | 219.13 | 228.54 | -9.4 |
| Bio-Techne | 2021-2025 | $228.3M | 79.49 | 103.58 | -24.1 |
| Cisco | 2021-2025 | $223.4M | 172.19 | 292.59 | -120.4 |
| Analog Devices | 2021-2025 | $217.2M | 215.75 | 274.22 | -58.5 |
| UnitedHealth | 2021-2025 | $217.1M | 102 | 148 | -46.0 |
| Thermo Fisher Scientific | 2021-2025 | $216.2M | 126.05 | 156.63 | -30.6 |
| PG&E | 2021-2025 | $206.0M | 130 | 145 | -15.0 |
| ConocoPhillips | 2021-2025 | $205.3M | 279.04 | 285.59 | -6.5 |
| CVS Health | 2021-2025 | $190.6M | 136.61 | 148.36 | -11.8 |
| Starbucks | 2021-2025 | $190.2M | 110.47 | 165.21 | -54.7 |
| NextEra Energy | 2021-2025 | $189.1M | 118.24 | 146.25 | -28.0 |
| Marsh McLennan | 2021-2025 | $188.0M | 171 | 203 | -32.0 |
| IQVIA | 2021-2025 | $184.2M | 125.81 | 186.82 | -61.0 |
| Fiserv | 2021-2025 | $183.8M | 59 | 203 | -144.0 |
| Procter & Gamble | 2021-2025 | $183.0M | 150.71 | 170.04 | -19.3 |

A negative gap can reflect a sharply rising benchmark. AMD's semiconductor index includes Nvidia. The gap must therefore be read with the peer index chosen by the issuer.

## F3: The observed peer-beat share is near one half

Of 493 TSR-comparable issuers, 227 beat their disclosed peer index over the available reporting window. The observed share is 46.0%, which is 4.0 percentage points below 50%. The 50% figure is an arithmetic reference, not a chance level: the share of issuers expected to beat their peer index by chance was not estimated. The S&P 100 v0.3 result was 46 of 96, or 47.9%. The two observed shares differ by 1.9 percentage points.

This is a descriptive comparison. No statistical baseline, hypothesis test or causal model was run. The result applies to the dated constituent snapshot and available filing windows, not to all public companies or all possible periods.

Median latest-year granted compensation is $17.84 million across 493 available values. The mean is $23.75 million, the 25th percentile is $12.86 million and the 75th percentile is $24.72 million. The S&P 100 v0.3 median was $28.37 million across 98 company rows. The S&P 500 issuer median is $10.53 million lower, or 37.1% below the S&P 100 value. This probably reflects, in part, the larger-company composition of the S&P 100. That inference was not tested.

## F4: Company TSR below 100 and negative CAP

Eighty-eight of 493 TSR-comparable issuers, 17.8%, report a company TSR index below 100 over the available window. The numerator is 88, the denominator is 493 and N is 493. The lowest disclosed indices are PayPal 25, Baxter 26.5, Moderna 28, Align 29, Block 29.91 and Charter 32.

Thirty-four of 495 issuers, 6.9%, report negative latest-year Compensation Actually Paid. The numerator is 34, the denominator is 495 and N is 495. The largest negative values are The Trade Desk -$856.8 million, Super Micro -$190.3 million, Airbnb -$89.2 million, Veeva -$88.1 million, ServiceNow -$83.3 million and Marvell -$69.7 million. Negative CAP reflects a fall in the fair value of equity included in the SEC calculation. It is not a repayment of cash by the executive.

## F5: The descriptive spectrum runs in both directions

The Trade Desk reported $835.0 million granted in 2021 and -$856.8 million CAP in 2025. Palantir reported $8.6 million granted and $11.09 billion CAP in 2025, with $16.38 billion CAP across 2021-2025. Welltower's 2025 granted figure is $821.1 million alongside a +190.4 peer gap. Broadcom's available-window CAP is $4.32 billion alongside a +939.0 peer gap.

The high-CAP, peer-lagging set is in F2. These juxtapositions do not support a causal or overpaid conclusion.

## F6: The board-target layer is an audited case layer

`board_targets.csv` contains 47 primary-verified cases. The strata are 29 original S&P 100 Layer A cases and 18 S&P 500 findings extensions. Each row carries its metric type, performance period, value basis, exact SEC accession, form, primary document, filing date and source locator.

Thirty-three of 47 cases contain a numeric featured percentage. Of those 33, 23 are above 100%, one equals 100% and nine are below 100%. Fourteen of 47 do not contain a comparable formulaic percentage. These counts must not be read as a common market distribution because annual cash bonuses, PSU outcomes, component payouts and special awards are different measures.

The primary recheck records, among other cases:

- American Tower's 2023-2025 PSU payout at 157% of target.
- Salesforce's fiscal 2026 annual cash payout at 103.3%.
- GE's 2025 annual cash payout at 188% after internal reallocation from 198% formulaic funding.
- ServiceNow's subscription-revenue component payout at 119.7%. The reported $12.85 billion result and $12.70 billion target are inputs to the component formula, not a direct 119.7% ratio and not a completed award payout.
- Palantir paid no 2025 service bonus and made no new equity grant to Alex Karp. No formulaic percentage is entered. Outstanding prior equity awards continued to vest. Mention of Palantir is not an allegation of wrongdoing.
- Goldman Sachs made an $80 million retention RSU award with five-year cliff vesting outside annual compensation. No formulaic percentage is entered.

## F7: Paywatch's published exclusion remains unassessed

The retained Executive Paywatch 2026 page reports the figures below. They are single-source observations of what AFL-CIO published, not a new audit of the underlying company filings. The data year is 2025 unless a row says 2024; the median company pay ratio tile gives no year. PW denotes source `SRC-2026-08-27-000`; M denotes its methodology, `SRC-2026-10-17-000`. Both are registered in `sources_v3.csv`. Line locators refer to the retained text extractions identified there.

| Figure | As printed | Extraction locator |
|---|---|---|
| Musk Tesla package, prose | $158 billion | PW 34 |
| Musk Tesla package, tile | $158.3 Billion | PW 42 to 43 |
| Musk Tesla package, also in prose | $158.3 billion | PW 81, 83 and 85 |
| Package relative to all other S&P 500 CEOs combined | 14 times higher | PW 34 |
| Average S&P 500 CEO pay, including | $340.1 million | PW 35 |
| Average S&P 500 CEO pay, excluding | $22.8 million | PW 35; tiles 54 to 55 |
| Average company pay ratio, including | 5,387-to-1 | PW 36; tiles 52 to 53 |
| Average company pay ratio, excluding | 312-to-1 | PW 36; tiles 56 to 57 |
| Median S&P 500 CEO pay | $17.3 Million | PW 58 to 59 |
| Median company pay ratio | 198-to-1 | PW 60 to 61 |
| Tesla CEO-to-worker pay ratio | 2,522,203-to-1 | PW 36; tiles 44 to 45 |
| 2024 average CEO pay comparison, excluding | $18.9 million | PW 35 and 63 |
| 2024 average pay-ratio comparison, excluding | 285-to-1 | PW 36 |

The package amount appears as $158 billion once in prose (PW line 34) and as $158.3 billion three times in prose (PW lines 81, 83 and 85). The tile reads $158.3 Billion (PW line 42). The difference is therefore present within the prose as well as between prose and tile.

The page names the exclusion in four ways:

- "Excluding Musk's Tesla pay package" (PW line 35).
- "Excluding Musk" (PW line 36).
- "Excluding Tesla" (the two tiles, PW lines 55 and 57).
- "excluding Elon Musk's Tesla compensation" (PW line 63).

The methodology bases the including average CEO compensation on 499 companies with available 2025 CEO pay data as of July 2026 (M line 38). It defines the average company pay ratio as the arithmetic mean of companies' disclosed pay ratios (M line 38). It does not state how the excluding figures are formed. Whether the exclusion removes Tesla as a company or only Musk's award remains unassessed.

For the including pay average, the source gives CEO compensation as the measure and 499 companies as the population; it does not state the aggregate compensation numerator. Its denominator and N are 499 companies. The source does not specify the excluding pay average's adjusted numerator, denominator or N. The published company pay ratios have the following boundaries; the 499-company count for average CEO compensation does not supply a separately stated N for each ratio statistic.

| Published ratio or multiple | Numerator | Denominator | N supplied by the source |
|---|---|---|---|
| 5,387-to-1, average including | CEO pay used in each company's disclosed ratio | That company's median employee pay; the statistic averages company ratios | No separate N for the ratio average (M lines 37 to 39) |
| 312-to-1, average excluding | Same company-ratio measure; the exclusion operation is unassessed | Same employee-pay basis; the exclusion operation is unassessed | Not stated for the excluding average (PW line 36; M lines 37 to 39) |
| 198-to-1, median | CEO pay used in each company's ratio | That company's median employee pay; the statistic is a median of company ratios | Not separately stated for the median (PW lines 60 to 61; M lines 37 to 39) |
| 2,522,203-to-1, Tesla | Musk's 2025 total compensation at Tesla | Median Tesla employee pay in 2025 | One company; employee count not given in the cited passage (PW line 36) |
| 285-to-1, 2024 comparison | CEO pay used in each company's ratio, with the published exclusion | That company's median employee pay | Not stated for this comparison (PW line 36) |
| 14 times higher, package comparison | Musk's Tesla pay package as reported by the page | Total compensation of all other S&P 500 company CEOs combined | Number of other CEOs not stated in the comparison (PW line 34) |

The methodology cautions that CEO pay used in a company's ratio may differ from its displayed Summary Compensation Table total (M line 37). For companies without available pay ratio data, the methodology describes comparing CEO pay with median annual income earned by U.S. workers (M line 39). The ratio statistics above are attributed to the publication; their underlying components and exclusion are not reconstructed here.

AFL-CIO is a labour advocacy publisher with a stated position on executive pay (PW lines 96 to 101). That incentive limits how its framing should be read; it does not establish that a reported figure is wrong. This section is not a defence of the pay levels.

## Method, coverage and reproducibility

- **Universe.** `universe_sp500.txt` contains 503 constituent securities from Wikipedia revision 1364118843, captured on 2026-07-16. The source is secondary and crowd-maintained. The list is adapted under CC BY-SA 4.0. HONA and FDXF are distinct securities, not duplicates of HON and FDX. The three dual-class pairs GOOGL/GOOG, FOXA/FOX and NWSA/NWS collapse by CIK.
- **Coverage.** The frozen spine contains 2,769 populated company-year rows for 498 securities and five placeholders. These collapse to 495 populated issuers. BX, KKR and PSKY remain unresolved through the staged proxy path. HONA and FDXF are recent spin-offs without a standalone Pay Versus Performance disclosure in the staged period.
- **Primary recoveries.** Intel uses the revised DEFR14A, accession `0000050863-26-000066`, for ten company-year rows. Erie uses DEF 14C accession `0001193125-26-116761` for five rows. American Tower uses DEF 14A accession `0001053507-26-000088` for six manually transcribed rows. Synchrony uses DEF 14A accession `0001601712-26-000017` for six manually transcribed rows.
- **Unresolved cases.** BX and PSKY have no accession in the staged standard proxy path. KKR has accession `0001140361-26-007164`, but no XBRL instance was extracted and no manual primary table has been entered. FDXF is SEC CIK `0002082247`; HONA is SEC CIK `0002089271`. Neither recent spin-off contributes a populated PvP row.
- **Tesla's FY2024 transcription.** Accession `0001104659-25-090866` discloses 2020 to 2024 in its Pay vs Performance table (R2; source `SRC-2026-10-17-001`). FY2024's CEO Summary Compensation Table total and CAP show a dash, and neither has a tagged CEO pay fact. The dash is read as nil for FY2024 CAP, consistently with the scorecard's existing zero reading of the same dash in the CEO total. The CEO total, name and selected-measure name remain blank in the spine, as in the other TSLA rows. The added row is flagged `MANUAL_PRIMARY_TABLE`; the issuer retains `EQUITY_ONLY_SCT_ZERO` from its other rows. The recorded pull rule builds company-years from tagged CEO pay facts and skips zero or blank CEO-total/CAP pairs. This rule probably omitted FY2024 because it has no tagged CEO pay fact. The full-universe spine builder is absent from the bundle, so that mechanism is not reproduced here.
- **Coverage boundary.** v3 adds Tesla's FY2024 row but does not search the other issuers' filings again for a year the pull rule could have omitted in the same way; such a year could sit among the five placeholders or the 17 issuer rows that do not carry five fiscal-year labels, while TPL and ECHO, whose latest fiscal year in the spine is 2024, first sent the proxy statements with their FY2025 tables in September 2026, after the spine's data date of 2026-08-09.
- **Reporting windows.** The spine labels a fiscal year by the calendar year it ended in, so labels can skip or meet where a 52- or 53-week year ends in early January: LHX, LDOS and TRMB read 2021 to 2023, 2025 and 2026 for five fiscal years. SNA's and SWK's fiscal 2021 rows, which shared the label 2022 and carried fiscal 2022's return and net income, are corrected from their 2026 proxies and keep the table's year, 2021, where that rule would give 2022. Of 495 issuer rows, 478 carry five labels, eight carry four, three carry three, three carry two, two carry one and one carries six. Of the shorter windows, AVY, CDNS, JNJ, KVUE and TDY have more rows than labels and unread filings, so may hold more fiscal years, and a row another year's return and net income, on TDY its latest. Every output row carries its start year, end year and year count.
- **TSR denominator.** AMZN lacks a parsed peer index. BLK lacks parsed company and peer indices. They remain in the 495-issuer view and are excluded from the 493-issuer peer comparison.
- **CEO transitions.** One hundred and ninety-eight issuer rows contain at least one `CEO_TRANSITION` flag. The available-window CAP may therefore sum more than one PEO. Eighty-three issuer rows retain a blank latest-CEO display because the automatic filing extraction did not support one singular name and no manually audited case supplied one; for AVB, CPAY and MPC it had taken text from the table's headings or notes.
- **CEO-name backfills.** Nineteen single-name backfills in `ceo_pay_data.csv` are tied to exact SEC accession, form, primary document and filing date. Five additional transition cases receive the manually audited name or names from `board_targets.csv`.
- **CAP caveat.** Compensation Actually Paid is the SEC fair-value remeasurement, not cash received. `Realised` is shorthand used in the display.
- **Near-zero denominators.** `cap_to_granted_x` is blank where the latest Summary Compensation Table total is missing or zero. Dollar CAP remains available.
- **Filer-error floor.** The S&P 100 v0.3 audit recorded one mis-signed CAP fact among 1,551 CAP facts. The numerator was one, the denominator was 1,551 and N was 1,551. Machine-readable data are not necessarily correct.
- **Reproduction boundary.** `python3 assemble_sp500.py` regenerates `scorecard_sp500.csv` from the frozen `pvp_pulled.csv`, `ceo_pay_data.csv` and `board_targets.csv`, and validates the input security set against `universe_sp500.txt`. The bundle does not contain a self-contained full-universe EDGAR repull script.

## Guardrails

- TSR is not caused by the CEO. Macro conditions, sector exposure, predecessor decisions and luck also affect it.
- The peer benchmark is selected or disclosed by the issuer. Its composition affects the gap.
- The 47-case board-target layer is non-random and mixes different metrics. Do not generalise its percentages to the S&P 500.
- S&P 500 membership is secondary-source and dated. Index membership changes.
- Survivorship: the universe is the constituent list of one dated snapshot. Companies that were in the index during a reporting window but are not in the snapshot are absent, and companies that joined the index during their window are included. The effect of this selection on the counts and shares was not measured.
- The analysis is descriptive and is not investment advice.

## Verification

- TSLA FY2024 is transcribed from R2 by outer-table column position: company TSR 1,448, peer TSR 285, net income $7,153,000,000 and selected-measure amount $97,690,000,000. The original and its digest are registered in `sources_v3.csv`; the tagged table cells for CEO total and CAP are empty, while the nested disclosure prints a dash. The CAP nil reading is a stated convention, not a tagged zero.
- F7 verifies wording and figures against the retained AFL-CIO page and its methodology, not against the underlying company filings. The package amount's prose/tile distribution and the four exclusion wordings are supported as publication observations. Which exclusion applies remains unassessed. The methodology's average-compensation population is separate from the scorecard's dated universe. `sources_v3.csv` records original-file digests and extraction locators.
- Every monetary, CAP and TSR row in `scorecard_sp500.csv` carries the SEC accession or accessions used for that issuer. The aggregate anchors, 227/493 peer beats, 88/493 TSR indices below 100, 34/495 negative latest-year CAP, 36/493 upper-quartile CAP peer lags and the distribution statistics, are derived by `assemble_sp500.py` from those rows.
- Every case in `board_targets.csv` has `PRIMARY_VERIFIED` status and names its exact SEC accession, form, primary document, filing date, metric period and locator. These 47 rows support the named-company claims in F1, F2, F4, F5 and F6.
- Welltower's grant structure and market-capitalisation thresholds were checked against DEF 14A accession `0000766704-26-000014`, filed 2026-04-10; `board_targets.csv` names its primary document.
- The four recovered filings are Intel `0000050863-26-000066`, Erie `0001193125-26-116761`, American Tower `0001053507-26-000088` and Synchrony `0001601712-26-000017`.
- The 19 CEO-name backfills in `ceo_pay_data.csv` have `PRIMARY_VERIFIED` status and accession-level source metadata. The remaining 80 blank display names are not represented as verified names.
- The S&P 500 membership list is not primary. It is Wikipedia revision 1364118843, captured on 2026-07-16 and normalised in `universe_sp500.txt`. That file identifies its source, modification and CC BY-SA 4.0 licence. No BlackRock holdings file or S&P factsheet is deposited or required to reproduce the issuer view.
- The S&P 100 comparison uses the published v0.3 frozen view: 46/96 TSR-comparable company rows and a $28,367,679.50 median latest-year grant across 98 company rows.
- No statistical baseline, hypothesis test or causal model was run. The 50% figure is labelled as an arithmetic reference, not a chance level.

## AI assistance, conflicts and limitations

The research design, method, sourcing decisions and analytical judgements are
the author's. Anthropic Opus 5.5 assisted with scope, source checks and the
review of this version. OpenAI GPT-6.1 Sol drafted this version's changes, and
Anthropic Opus 5.5 drafted the corrections made after them, so this text was
artificially generated and was reviewed by the author before publication. Both
ran as command-line agents working on local files. Moonshot Kimi K3.1 Pro, also
run as a command-line agent, independently reviewed the Tesla rows and the
counts that changed with them, and Google Gemini 4 Argon High, run the same way,
reviewed those rows again with the rows corrected since and the texts. The
assisting and reviewing models are not always neutral parties to the subject
matter: Anthropic, OpenAI, Moonshot and Google supply AI models and compete with
some issuers' AI products, and Google's parent, Alphabet, is an issuer in this
dataset. These are potential conflicts, not evidence that any result is wrong.

The author holds no direct position in any company named. A workplace
defined-contribution pension may hold some names indirectly through pooled funds
not directed by the author. No third party funded or directed the work.

Guarantee: every measured claim is traced to the primary document named in the
Verification note. assemble_sp500.py regenerates scorecard_sp500.csv from
pvp_pulled.csv, ceo_pay_data.csv and board_targets.csv, and validates inputs
against universe_sp500.txt. The Paywatch table transcribes the retained
publication; it does not recalculate its underlying pay data. Modelled or
estimated inputs are identified as such in the Verification note rather than
presented as measurements. A reader can check this without trusting either party.

What the author cannot guarantee: a language model's output can be wrong in ways
that survive review. In prose the error is locally plausible and consistent in
tone with what surrounds it; in code it simply runs, and a wrong constant or a
mis-set filter still returns a clean number. Several methods have been deployed to
mitigate this, including explicit instructions, internal red-teaming and
cross-lab blindspot checks, but the author does not claim the review is
exhaustive. Corrections are logged against the DOI when surfaced.

No warranty is offered beyond the terms of the CC BY 4.0 licence.
The CC BY-SA 4.0 terms apply to `universe_sp500.txt`. Independent analysis and
open-science documentation only, not investment advice.

## Version history (for reference)

- **v3, 2026-11-06.** (1) Added TSLA FY2024 from the primary table, with the CAP dash read as nil, and rebuilt the issuer view. (2) Corrected the two Tesla window sentences: the source and repaired row cover 2020 to 2024. (3) Added the Paywatch section with its exclusion unassessed. (4) Added `sources_v3.csv` from the retained-source checks. (5) Removed the U+26D4 marker from the findings. (6) F2's table now lists all 36 issuers of its set, where it showed a selection, and its Workday and Flex windows now read 2022-2026, from `scorecard_sp500.csv`. (7) Reworded F4's heading, F5's sentence naming four companies and the interactive view's subtitle and notes as plain description, and added that naming a company or CEO alleges nothing. (8) Corrected SNA's and SWK's fiscal 2021 rows, removed SNA's `CEO_TRANSITION` flag and stated how years are labelled.
- **v2.2, 2026-08-09.** Assisting models: Anthropic Opus 4.8 and OpenAI GPT-5.6 Sol. The issuer view now carries explicit reporting-window bounds and SEC source accessions. Intel, Erie, American Tower and Synchrony were recovered from primary filings. The original 29-case S&P 100 board-target layer was rechecked and extended by 18 named S&P 500 cases. Welltower's award conditions, Tesla's then-recorded window (superseded by the v3 correction), ServiceNow's component payout and the CEO-name backfills were corrected or qualified against primary filings.
- **WITHDRAWN, v2.1 universe treatment.** v2.1 described HONA and FDXF as scrape duplicates of HON and FDX and excluded them. They are distinct SEC registrants and distinct securities in the dated source snapshot. v2.2 retains both as recent-spin-off placeholders. The universe denominator is therefore 503 securities, of which 498 have populated PvP rows and five are placeholders. The 495-issuer findings are unchanged because neither HONA nor FDXF contributes a populated PvP row.
- **v2.1, DOI 10.5281/zenodo.21446828.** Completed 19 CEO display-name backfills. This is an earlier published version.
- **S&P 100 comparison.** The earlier edition is v0.3, concept DOI 10.5281/zenodo.20680108, version record 21193094.
