# CEO pay scorecard: method map

This example is v3 of the CEO Pay-vs-Delivery Scorecard, S&P 500 edition, [Zenodo record 24018716](https://zenodo.org/records/24018716), DOI [10.5281/zenodo.24018716](https://doi.org/10.5281/zenodo.24018716). Its findings, README, data, code and interactive view are CC BY 4.0; `universe_sp500.txt` is CC BY-SA 4.0; the two files in `evidence/2026-10-17/` are copies of a page from a public SEC filing, outside the bundle's licence (bundle README_v3.md, Licence and source boundary). The SEC spine is frozen and the constituent list is a dated snapshot (bundle README_v3.md, Scope). The licence copy is [CEO_PAY_SCORECARD_LICENSE.txt](CEO_PAY_SCORECARD_LICENSE.txt).

The analysis is descriptive. The tables place disclosed pay measures beside issuer-selected peer benchmarks, no overpaid verdict is issued, and naming a company or CEO alleges nothing (bundle README_v3.md, Scope; findings_v3.md, opening paragraphs).

## Where to inspect each step

Kit locators refer to files in the kit's top folder. Bundle locators refer to files in [ceo-pay-scorecard-v3/](ceo-pay-scorecard-v3/). Each row identifies material to inspect, without certifying that the whole step was performed.

| Kit step | Kit locator | Bundle locator | What can be inspected |
|---|---|---|---|
| 1. Question | RESEARCH_FRAMEWORK.md, 1. Question | findings_v3.md, opening paragraphs; README_v3.md, Scope | The descriptive scope and its interpretive limits. |
| 2. Scope and method | RESEARCH_FRAMEWORK.md, 2. Scope and method | findings_v3.md, Method, coverage and reproducibility; universe_sp500.txt, header lines | The dated universe, the frozen spine, the collapse of dual share classes by SEC CIK and the coverage boundary. A complete pre-outcome plan is not supplied. |
| 3. Novelty and usefulness | RESEARCH_FRAMEWORK.md, 3. Novelty and usefulness | findings_v3.md, Verification, the S&P 100 comparison; findings_v3.md, F7 | The comparison with the earlier S&P 100 edition, and single-source observations of what AFL-CIO's Executive Paywatch published. This is not a demonstration of novelty or usefulness, and no prior-work search record is supplied. |
| 4. Source evidence | RESEARCH_FRAMEWORK.md, 4. Source evidence | sources_v3.csv, official_url, local_path, sha256, support_status and notes; scorecard_sp500.csv, source_accessions; board_targets.csv | The source register with retained-original digests and support limits, and the SEC accessions behind each issuer row. The retained originals are excluded; the deposit holds a cleaned copy of one, the TSLA page, and its text extraction (README_v3.md, Deposit files; sources_v3.csv, SRC-2026-10-17-001). |
| 5. Analysis | RESEARCH_FRAMEWORK.md, 5. Analysis | assemble_sp500.py; README_v3.md, Headline measurements; findings_v3.md, F1 to F6 | The aggregation rule, the counts it prints and the findings that use them. No statistical baseline, hypothesis test or causal model was run (findings_v3.md, Verification). |
| 6. Challenge and revision | RESEARCH_FRAMEWORK.md, 6. Challenge and revision | findings_v3.md, Verification and Version history; README_v3.md, AI assistance, conflicts and limitations | Recorded verification notes, the outside reviews the disclosure names and each version's corrections. The review trails are excluded (README_v3.md, Deposit files). This is not fresh source review. |
| 7. Publication and maintenance | RESEARCH_FRAMEWORK.md, 7. Publication and maintenance | README_v3.md, Reproduce the issuer view; Licence and source boundary; AI assistance, conflicts and limitations | The run instruction, the licence split and the disclosure. Not shown in this bundle: a maintenance or corrections log. |
| Align records | WORKFLOW.md, stage table, Align records | Not shown in this bundle | The file table lists the deposit's files (README_v3.md, Deposit files), but a cross-location release comparison is not supplied. |
| Monitor and reuse | WORKFLOW.md, stage table, Monitor and reuse | Not shown in this bundle | No post-release monitoring or actual reuse is recorded. Regenerating the issuer view below is a reproduction, not a reuse record. |

## Commands to try

The bundle's README_v3.md, Reproduce the issuer view, gives the command, run from the extracted bundle. The script reads its inputs and writes `scorecard_sp500.csv` by bare file names, so in the folder it runs in, and it uses only the Python standard library. From the kit's top folder, run in your terminal:

```sh
mkdir ../ceo-pay-regenerated &&
cp -R examples/ceo-pay-scorecard-v3/. ../ceo-pay-regenerated/ &&
(cd ../ceo-pay-regenerated && python3 -B assemble_sp500.py) &&
cmp ../ceo-pay-regenerated/scorecard_sp500.csv examples/ceo-pay-scorecard-v3/scorecard_sp500.csv &&
echo "same bytes"
```

If `../ceo-pay-regenerated` already exists, `mkdir` fails and nothing else runs. The script runs inside the copy, checks its inputs against universe_sp500.txt and stops on a mismatch before writing anything. When the regenerated issuer view equals the deposited one, `cmp` prints nothing and `echo` prints `same bytes`. The script also prints its counts and two lists of issuers ordered by disclosed figures; the bundle states its published figures in README_v3.md, Headline measurements. These commands were run on Linux only. On Windows, copy the folder by hand and run `py -3 -X utf8 -B assemble_sp500.py` in the copy, as the bundle's files are UTF-8; that route is untested.

## Limits

The map points to where steps can be inspected. It is not evidence that the kit was used to make the scorecard, that the scorecard's findings are right, or that the kit improves research quality. Regenerating the issuer view checks the aggregation from the three frozen CSV inputs only: the bundle holds no full-universe EDGAR repull script, so the SEC spine itself is not reproduced (README_v3.md, Reproduce the issuer view; findings_v3.md, Method, coverage and reproducibility, Reproduction boundary). The analysis is descriptive and is not investment advice (README_v3.md, Guardrails).
