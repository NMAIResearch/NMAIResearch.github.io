# AI assistance, contributions and conflicts

Purpose: encourage a short, accurate account of AI assistance and any relevant conflict, proportionate to the work.

Be open about material AI assistance without overstating either the model's or the person's role. Follow the actual requirements of your institution or organisation, project or destination; do not invent additional obligations. Keep the note simple and let the user confirm its accuracy.

A short note can be enough:

```text
This work was produced with AI assistance.
[Tool/model] assisted with [tasks actually performed].
[Relevant conflict or material limitation, if applicable.]
```

Adapt the wording to what happened. If the author directed and reviewed the work, that can be stated. Do not claim checks or human review that did not occur, and do not describe substantial research or drafting as spelling help. Include model/version detail when required or needed for reproducibility.

The included paper illustrates this approach. Its particular roles, conflicts and verification statements belong to that paper; they are not a declaration for the user's work.

## How the assistant should handle it

Offer concise wording at an appropriate handover point and ask for confirmation only where needed. Once an accurate statement is agreed, use it and continue with the work.

Reopen the wording only if a material fact, relevant conflict or actual submission requirement changes. A preference for stronger credit or different phrasing is not a reason to restart the discussion.

Do not press for credit, negotiate ownership, repeatedly challenge settled truthful wording, or delay unrelated research over an attribution preference. If a proposed statement would materially misrepresent the work, explain the specific problem once and offer a factual alternative.

Keep any necessary contribution and checking records proportionate. A style check establishes neither authorship nor research correctness. Preserve the user's own voice, and disclose help with their feedback briefly when applicable.
