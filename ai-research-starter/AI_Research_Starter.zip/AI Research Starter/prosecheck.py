

"""Check prose against the NM AI Research house style and internal-marker profile.

Purpose: flag configured style, voice, attribution and internal-marker patterns.
Usage: python3 prosecheck.py FILE [FILE ...]
A pass is not evidence of human authorship, factual accuracy or safe publication.
Every finding needs contextual review; preserve necessary evidence and qualifiers.
"""
import sys
import re

DASHES = {"em-dash": "—", "en-dash": "–"}

FIRM_WORDS = [
    "robust", "delve", "tapestry", "seamless",
]

FIRST_PERSON = re.compile(r"(?<![A-Za-z'’])(I(?![.\-/])|I'm|I’m|I've|I’ve|I'd|I’d|I'll|I’ll|"
                          r"[Mm]y|[Mm]yself)(?![A-Za-z'’])")
QUOTED = re.compile(r"\"[^\"]*\"|“[^”]*”|'[^']{6,}'")
URL = re.compile(r"https?://\S+|www\.\S+")
PROSE_ONLY = (".md", ".markdown")

# Mask only the initial, so narration elsewhere on the same line is still checked.
NONVOICE_INITIALS = (
    ("device-class", re.compile(r"\bClass[ \t]+(?P<initial>I)\b")),
    ("author-list", re.compile(
        r"\b[A-Z][A-Za-z'’\-]+[ \t]+(?P<initial>I)"
        r"(?=,[ \t]+[A-Z][A-Za-z'’\-]+[ \t]+[A-Z](?:[.,;]|\b))")),
)


def mask_nonvoice_initials(text):
    """Return text with recognised technical initials masked and named cases."""
    spans = []
    for label, pattern in NONVOICE_INITIALS:
        spans.extend((match.start('initial'), match.end('initial'), label)
                     for match in pattern.finditer(text))
    chars = list(text)
    for start, end, _label in spans:
        chars[start:end] = ' ' * (end - start)
    return ''.join(chars), [label for _start, _end, label in spans]

WATCH = [
    "moreover", "furthermore", "additionally", "consequently", "overall",
    "it is important to note", "it's worth noting", "at its core",
    "in today's fast-paced world", "underscore", "showcase",
    "foster", "holistic", "pivotal",
    "landscape", "leverage", "comprehensive",

    "toolkit", "buys you", "what it buys", "unlock",
    "overarching", "undergird", "nestled",
]

CADENCE = [
    ("we-report-it-as",  r"\bwe (report|state|treat|flag|record|mark) (it|this|them|that)\b"),      
    ("meta-justify",     r"\b(reported|recorded|stated|included|kept|noted)( here| it| this)? because\b"),  
    ("rather-than-hide", r"\b(rather than|instead of) (hid|assum|defend|apolog|guess)\w*"),          
    ("exactly-intensif", r"\bexactly (where|what|how|the)\b"),                                       
    ("superlative-self", r"\bthe (sharpest|strongest|clearest|hardest|key|central|whole) \w+ (in|of) (the|this)\b"),  
    ("worth-verbing",    r"\bworth (noting|naming|stating|saying|flagging|recording)\b"),            
    ("copula-slogan",    r"\bis the (point|finding|demonstration|contribution|thesis|argument|answer|failure)\b"),  
    ("not-X-it-is-Y",    r"\bis not\b[^.]{3,60},\s*(it is|and)\b"),                                  
    ("emphatic-pivot",   r"\band it (bears on|cuts against|matters|goes|runs)\b"),                   
]

SELFNARRATION = [
    ("doc-as-agent",     r"\bthis (issue|note|paper|section|piece|series|document) (makes|owes|carries|withdraws|adds|holds|offers|reports|argues|says|does not|replaces|treats)\b"),  
    ("honesty-perf",     r"\bthe honest (statement|version|read|reading|number|answer|framing|other side)\b"),  
    ("doc-intent",       r"\b(kept|held|placed|offered|quoted|reported|stated|included|written|framed)\b[^.]{0,40}\b(on purpose|deliberately|precisely because)\b"),  
    ("reader-address",   r"\ba reader (will|would|might|could|may)\b"),                              
    ("discipline-is",    r"\bthe discipline (is|here is|has to be)\b"),                              
    ("is-itself-the",    r"\bis itself the (finding|point|story|argument|tell|signal)\b"),           
    ("what-can-defend",  r"\b(the claim|what) this (issue|note|paper|series) can (defend|support|carry|claim)\b"),  
    ("not-pretend",      r"\b(does not|do not) pretend\b"),                                          
    ("in-miniature",     r"\bin miniature\b"),                                                       
    ("kept-off-purpose", r"\b(kept|held) (off|apart|separate)[^.]{0,30}\bon purpose\b"),             
    ("owed-correction",  r"\bthe correction (this|it) ?(issue|note|paper)? ?owes\b"),                
]

LEAK = [
    ("career-pivot",     r"\b(career[- ]pivot|pivot(ing)? in(to)? (the )?(ai|artificial intelligence|analy)|AI[- ]industry[- ]adjacent|job[- ]hunt|seeking a (role|position))"),
    ("personal-circum",  r"\b(the author is (currently )?(pivot|seek|transition|looking|between)|his own market|his career)"),
    ("tracker-marks",    r"(§(RC|DR|SL)\b|MASTER_TRACKER|PROJECT_INDEX|ISSUE\d_fragment|_PARKED\b)"),
    ("wiki-link",        r"\[\[[a-z0-9-]+\]\]"),
    ("working-todo",     r"\b(note to self|TODO|do not bank|verify before citing|before drafting|re-verify before|his call|N's )\b"),
    ("parked-marker",    r"(⛔|↻ \[?20\d\d-|⭐ ?\[?20\d\d-)"),
    ("phone-number",     r"(\+\d{1,3}[\s-]?\d{3,5}[\s-]?\d{3,6}\b|\b07\d{3}[\s-]?\d{6}\b)"),

    ("operating-card-ref", r"(\(Rules? \d+[^)]*\)|\bRules? \d+ to \d+\b|UNIVERSAL_OPERATING_CARD|\bCore Seven\b|\boperating card\b)"),

    ("chat-emoji",       "[\U0001F300-\U0001FAFF✅❌⚠❗❓⭐⛔✔✖]"),
]

ATTRIB = [
    ("maker-of-author",  r"\bauthors?'?’?s (maker|makers|creator|developer)\b"),
    ("this-authors",     r"\bthis author's?\b"),
    ("first-person-own", r"\bmy (maker|creator|developer)\b"),
    ("model-as-author",  r"\bauthored by (an? )?(AI|artificial intelligence|language model|LLM|Anthropic|Claude|model)\b"),
    ("model-owns-work",  r"\b(the model|the assistant)'s? (paper|analysis|findings|conclusions)\b"),
]

def scan(path):
    try:
        with open(path, encoding="utf-8") as handle:
            lines = handle.read().splitlines()
    except OSError as e:
        print(f"  ! cannot read {path}: {e}")
        return 1
    is_prose = path.lower().endswith(PROSE_ONLY)
    words = max(sum(len(l.split()) for l in lines), 1)
    dash_hits, word_hits, cadence_hits, self_hits, leak_hits = [], [], [], [], []
    attrib_hits = []
    firmword_hits = []
    firstperson_hits = []
    voice_exemptions = []
    for i, line in enumerate(lines, 1):

        dash_test = re.sub(r"(?<=\d)\u2013(?=\d)", "", line)
        for name, ch in DASHES.items():
            if ch in dash_test:
                dash_hits.append((i, name, line.strip()))
        low = line.lower()

        window = " ".join(lines[max(0, i - 2):i + 1]).lower()
        in_withdrawal = "withdrawn" in window or "⛔" in window
        for w in FIRM_WORDS:
            if re.search(r"\b" + re.escape(w) + r"\b", low) and not in_withdrawal:
                firmword_hits.append((i, w, line.strip()))

        if is_prose and not line.lstrip().startswith(">"):
            unquoted = URL.sub(" ", QUOTED.sub(" ", line))
            unquoted, exempted = mask_nonvoice_initials(unquoted)
            voice_exemptions.extend((i, label) for label in exempted)
            m = FIRST_PERSON.search(unquoted)
            if m:
                firstperson_hits.append((i, m.group(0), line.strip()))
        for w in WATCH:
            if re.search(r"\b" + re.escape(w) + r"\b", low):
                word_hits.append((i, w, line.strip()))
        for name, rx in CADENCE:
            if re.search(rx, line, re.I):
                cadence_hits.append((i, name, line.strip()))
        for name, rx in SELFNARRATION:
            if re.search(rx, line, re.I):
                self_hits.append((i, name, line.strip()))
        for name, rx in LEAK:
            if not re.search(rx, line, re.I):
                continue

            if name == "parked-marker" and re.search(
                    r"withdraw|supersed|retired|replaced by", window):
                continue
            leak_hits.append((i, name, line.strip()))
        for name, rx in ATTRIB:
            if re.search(rx, line, re.I):
                attrib_hits.append((i, name, line.strip()))
    print(f"\n== {path} ==")
    if voice_exemptions:
        print("  VOICE EXCEPTIONS: recognised technical initials (not a source check):")
        for line_number, label in voice_exemptions:
            print(f"    L{line_number} [{label}]")
    if leak_hits:
        print(f"  FIRM/LEAK: {len(leak_hits)} internal-only item(s). These must not ship:")
        for i, name, s in leak_hits:
            print(f"    L{i} [{name}]: {s[:110]}")
    else:
        print("  FIRM/LEAK: nothing internal-only. good.")
    if attrib_hits:
        print(f"  FIRM/ATTRIB: {len(attrib_hits)} attribution problem(s). Check the actual")
        print("               provider and contributions; retain accurate AI disclosure:")
        for i, name, s in attrib_hits:
            print(f"    L{i} [{name}]: {s[:110]}")
    else:
        print("  FIRM/ATTRIB: no model-as-author attribution. good.")
    if dash_hits:
        print(f"  FIRM: {len(dash_hits)} dash(es) to remove:")
        for i, name, s in dash_hits:
            print(f"    L{i} [{name}]: {s[:100]}")
    else:
        print("  FIRM: no em/en dashes. good.")
    if firstperson_hits:
        print(f"  FIRM/VOICE: {len(firstperson_hits)} first-person passage(s) flagged by the house profile.")
        print("  Check context: preserve human testimony and disclose AI assistance:")
        for i, w, s in firstperson_hits:
            print(f"    L{i} [{w}]: {s[:100]}")
    else:
        print("  FIRM/VOICE: no configured first-person matches; not an authorship test."
              if is_prose else "  FIRM/VOICE: skipped, not prose.")

    if firmword_hits:
        print(f"  FIRM/WORD: {len(firmword_hits)} aged tell(s). These must not ship:")
        for i, w, s in firmword_hits:
            print(f"    L{i} [{w}]: {s[:100]}")
    else:
        print("  FIRM/WORD: no aged tells. good.")
    if word_hits:
        print(f"  WATCH ({len(word_hits)}, advisory - fine where they fit):")
        for i, w, s in word_hits:
            print(f"    L{i} [{w}]: {s[:100]}")
    else:
        print("  WATCH: no watch-list words.")
    rate = len(cadence_hits) / (words / 1000)
    if cadence_hits:
        verdict = ("unremarkable" if rate < 0.5 else
                   "noticeable" if rate < 2.0 else "reads as generated")
        print(f"  CADENCE ({len(cadence_hits)} in {words} words = {rate:.1f}/1k, {verdict}):")
        counts = {}
        for _, n, _ in cadence_hits:
            counts[n] = counts.get(n, 0) + 1
        for n, c in sorted(counts.items(), key=lambda kv: -kv[1]):
            print(f"    {c:>3}x {n}")
        for i, n, s in cadence_hits:
            print(f"    L{i} [{n}]: {s[:100]}")
    else:
        print(f"  CADENCE: none in {words} words.")
    srate = len(self_hits) / (words / 1000)
    if self_hits:
        sverdict = ("unremarkable" if srate < 0.5 else
                    "noticeable" if srate < 2.0 else "the note is talking about itself")
        print(f"  SELF-NARRATION ({len(self_hits)} in {words} words = {srate:.1f}/1k, {sverdict}):")
        scounts = {}
        for _, n, _ in self_hits:
            scounts[n] = scounts.get(n, 0) + 1
        for n, c in sorted(scounts.items(), key=lambda kv: -kv[1]):
            print(f"    {c:>3}x {n}")
        for i, n, s in self_hits:
            print(f"    L{i} [{n}]: {s[:100]}")
    else:
        print(f"  SELF-NARRATION: none in {words} words.")

    return (len(leak_hits) + len(attrib_hits) + len(dash_hits) + len(firmword_hits)
            + len(firstperson_hits))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    firm = sum(scan(p) or 0 for p in sys.argv[1:])
    if firm:
        print(f"\n  {firm} FIRM hit(s) across {len(sys.argv) - 1} file(s). Not fit to ship.")
    sys.exit(1 if firm else 0)
