# Failure cases and blocked checks

Purpose: illustrate what the supplied tools can catch and how an assistant should respond. Code examples are synthetic fixtures, not attributed transcripts from Claude or any other model. The checker tests create disposable files and inspect them without running their contents.

## Python with a JSON literal

An assistant puts `null` into Python code. The static gate flags V002. Establish whether the intended value is Python's `None`, then repair and rerun the relevant behaviour test. Replacing a word is not enough if the intended behaviour remains unclear.

## A swallowed failure

A broad exception handler contains only `pass`. V006 flags it. Determine what can fail, what the user should see and whether the operation must stop. Narrow the exception handling and test the failure path. Do not add an arbitrary print statement solely to evade the detector.

## Shell execution hidden in a helper

The code uses `shell=True`, `os.system` or `os.popen`. The gate flags the applicable pattern. Examine the command and input boundaries. Use a fixed argument list where suitable and check how failures propagate. Do not rename or wrap the risky call just to conceal it from the scan.

## Ambiguous JSON

An input repeats a key or contains a non-standard constant such as `NaN`. The gate rejects the input. Clarify the intended data and correct the source. Do not accept whichever duplicate happens to survive parsing.

## A checker falsely flags necessary prose

The house prose checker may flag a first-person quotation, a user-facing prompt, a necessary technical word or another legitimate academic convention. It also reflects the author's punctuation and style preferences.

Classify the finding as a named false positive when justified, preserve the wording and record the reason. Do not describe the checker as clean. Never remove a caveat, method step or necessary quotation to change an exit code. Follow the user's actual assessment requirements rather than treating the house style as a universal writing rule.

## A stale status record

An old note says a task is unfinished, while a later release closes it. Reading the old note alone produces a false current claim. Check the current version and later correction records before asserting status. Preserve the historical note; correct the current conclusion visibly.

## A claimed test with no execution

The assistant says a test passed after only reading the code. Require the executed command, result and relevant environment. If execution was unavailable, report the test as not run. An intended result is not an observed result.

## A refusal treated as an obstacle to route around

A permission hook or checker blocks an action. Record the target, the proposed action and the refusal. Determine whether the issue is a real defect, an environment limitation or a false positive. Do not use another tool, edit the hook, weaken a test or change a protected threshold to bypass the same boundary. Obtain the required authorisation where applicable.

The pack does not include or install the author's local permission hooks. It cannot prevent every unsafe action by an AI assistant. These examples explain a response discipline and provide testable mechanical cases.
