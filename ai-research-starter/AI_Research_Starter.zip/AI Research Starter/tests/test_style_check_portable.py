"""Check the portable prose scanner's observable behaviour and file handling."""
import contextlib
import hashlib
import io
from pathlib import Path
import tempfile
import unittest
import warnings

import style_check


class StyleCheckPortableTests(unittest.TestCase):
    def scan(self, text, suffix='.md'):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / ('sample' + suffix)
            path.write_text(text, encoding='utf-8')
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            out = io.StringIO()
            with warnings.catch_warnings(record=True) as caught, contextlib.redirect_stdout(out):
                warnings.simplefilter('always', ResourceWarning)
                result = style_check.scan(str(path))
            self.assertFalse(any(issubclass(w.category, ResourceWarning) for w in caught))
            self.assertEqual(before, hashlib.sha256(path.read_bytes()).hexdigest())
            return result, out.getvalue()

    def test_plain_prose_passes_without_resource_warning(self):
        self.assertEqual(self.scan('The source was inspected.\n')[0], 0)

    def test_prose_dash_is_flagged(self):
        self.assertGreater(self.scan('Evidence\u2014with a qualification.\n')[0], 0)

    def test_numeric_range_is_permitted(self):
        self.assertEqual(self.scan('The example range is 1\u20132.\n')[0], 0)

    def test_firm_word_is_flagged(self):
        self.assertIn('FIRM/WORD: 1', self.scan('A robust example.\n')[1])

    def test_quoted_first_person_is_exempt(self):
        self.assertEqual(self.scan('The example says "I checked the file".\n')[0], 0)

    def test_reader_prompt_fence_retains_known_voice_false_positive(self):
        self.assertIn('FIRM/VOICE: 1', self.scan('```text\nI need a review.\n```\n')[1])

    def test_missing_file_is_a_failure(self):
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(style_check.scan(str(Path(folder) / 'absent.md')), 1)

    def test_device_class_initial_is_not_narration(self):
        result, output = self.scan('The Class I device is listed.\n')
        self.assertEqual(result, 0)
        self.assertIn('[device-class]', output)

    def test_reported_author_list_initial_is_not_narration(self):
        result, output = self.scan('| C45 | Source | Danylenko I, Unold O. PsyArXiv 2025, doi:10.31234/osf.io/enrbq_v1 |\n')
        self.assertEqual(result, 0)
        self.assertIn('[author-list]', output)

    def test_initial_exception_does_not_hide_later_narration(self):
        for text in ('The Class I device is listed; I checked it.',
                     'Danylenko I, Unold O. published it; I verified the source.',
                     'Class I and Class I devices appear in my review.'):
            with self.subTest(text=text):
                self.assertIn('FIRM/VOICE: 1', self.scan(text)[1])

    def test_initial_exception_does_not_hide_earlier_narration(self):
        self.assertIn('FIRM/VOICE: 1', self.scan('I reviewed Class I devices.')[1])

    def test_ordinary_first_person_remains_a_failure(self):
        for text in ('I checked the source.', 'Today I reviewed the paper.',
                     'In class I checked the source.', 'My finding is provisional.',
                     'Danylenko I checked the source.'):
            with self.subTest(text=text):
                self.assertGreater(self.scan(text)[0], 0)

    def test_other_detectors_still_apply_to_exempted_line(self):
        for text in ('The Class I device is robust.',
                     'Danylenko I, Unold O.\u2014source.',
                     'Class I devices: MASTER_TRACKER reference.'):
            with self.subTest(text=text):
                self.assertGreater(self.scan(text)[0], 0)

    def test_unresolved_single_initial_stays_flagged(self):
        self.assertIn('FIRM/VOICE: 1', self.scan('Author: Danylenko I; review.')[1])


if __name__ == '__main__':
    unittest.main()
