#!/usr/bin/env python3
"""Regression tests for the bounded generated-code static gate."""

from __future__ import annotations

import contextlib
import io
import json
import re
import tempfile
import unittest
from pathlib import Path

from vibecode_gate import RULES, inspect_json, inspect_python, main, run


class VibecodeGateTests(unittest.TestCase):
    def inspect_source(self, source: str) -> set[str]:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "candidate.py"
            path.write_text(source, encoding="utf-8")
            return {finding.code for finding in inspect_python(path)}

    def test_syntax_error_is_rejected(self) -> None:
        self.assertEqual(self.inspect_source("if True print('x')\n"), {"V001"})

    def test_bare_json_literal_is_rejected(self) -> None:
        self.assertEqual(self.inspect_source("value = null\n"), {"V002"})

    def test_eval_and_shell_execution_are_rejected(self) -> None:
        codes = self.inspect_source(
            "import subprocess\neval('1')\nsubprocess.run(['x'], shell=True)\n"
        )
        self.assertEqual(codes, {"V003", "V004"})

    def test_followlinks_and_silent_broad_exception_are_rejected(self) -> None:
        codes = self.inspect_source(
            "import os\nfor item in os.walk('/tmp', followlinks=True):\n"
            "    pass\ntry:\n    pass\nexcept Exception:\n    pass\n"
        )
        self.assertEqual(codes, {"V005", "V006"})

    def test_invalid_json_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "candidate.json"
            path.write_text('{"missing": }\n', encoding="utf-8")
            self.assertEqual({finding.code for finding in inspect_json(path)}, {"V007"})

    def test_explicit_clean_files_pass(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            python_file = root / "candidate.py"
            json_file = root / "candidate.json"
            python_file.write_text("VALUE = 1\n", encoding="utf-8")
            json_file.write_text('{"value": 1}\n', encoding="utf-8")
            self.assertEqual(run([python_file, json_file]), [])


class VibecodeGateRevisionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)

    def tearDown(self) -> None:
        self.directory.cleanup()

    def write(self, name: str, data: bytes) -> Path:
        path = self.root / name
        path.write_bytes(data)
        return path

    def python_codes(self, source: str) -> set[str]:
        return {f.code for f in inspect_python(self.write("candidate.py", source.encode("utf-8")))}

    def json_codes(self, text: str) -> set[str]:
        return {f.code for f in inspect_json(self.write("candidate.json", text.encode("utf-8")))}

    def call_main(self, argv: list[str]) -> tuple[int, str]:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(argv)
        return code, output.getvalue()

    def test_unsupported_file_type_fails_instead_of_counting_as_checked(self) -> None:
        notes = self.write("notes.txt", b"x = 1\n")
        self.assertEqual([f.code for f in run([notes])], ["V009"])
        code, output = self.call_main([str(notes)])
        self.assertEqual(code, 1)
        self.assertNotIn("PASS", output)

    def test_python_with_utf8_bom_parses(self) -> None:
        path = self.write("bom.py", b"\xef\xbb\xbfVALUE = 1\n")
        self.assertEqual(inspect_python(path), [])

    def test_bom_does_not_hide_other_findings(self) -> None:
        path = self.write("bom.py", b"\xef\xbb\xbfVALUE = null\n")
        self.assertEqual({f.code for f in inspect_python(path)}, {"V002"})

    def test_declared_latin1_source_parses(self) -> None:
        path = self.write("latin1.py", b'# -*- coding: latin-1 -*-\nname = "caf\xe9"\n')
        self.assertEqual(inspect_python(path), [])

    def test_undeclared_non_utf8_source_is_a_finding_not_a_crash(self) -> None:
        path = self.write("bad.py", b'name = "caf\xe9"\n')
        self.assertEqual({f.code for f in inspect_python(path)}, {"V001"})

    def test_unknown_declared_encoding_is_a_finding(self) -> None:
        path = self.write("bad.py", b"# -*- coding: no-such-codec -*-\nx = 1\n")
        self.assertEqual({f.code for f in inspect_python(path)}, {"V001"})

    def test_missing_and_directory_paths_are_unreadable_findings(self) -> None:
        (self.root / "folder.py").mkdir()
        paths = [self.root / "missing.py", self.root / "missing.json", self.root / "folder.py"]
        self.assertEqual([f.code for f in run(paths)], ["V008", "V008", "V008"])

    def test_silent_broad_handlers_with_ellipsis_constant_or_tuple_fail(self) -> None:
        for body, clause in [
            ("...", "except Exception:"),
            ("'ignored'", "except BaseException:"),
            ("pass", "except (Exception, ValueError):"),
            ("...", "except:"),
        ]:
            with self.subTest(clause=clause, body=body):
                source = f"try:\n    x = 1\n{clause}\n    {body}\n"
                self.assertEqual(self.python_codes(source), {"V006"})

    def test_narrow_or_acting_handlers_pass(self) -> None:
        for clause, body in [
            ("except ValueError:", "pass"),
            ("except (ValueError, KeyError):", "..."),
            ("except Exception:", "raise"),
            ("except Exception as exc:", "print(exc)"),
        ]:
            with self.subTest(clause=clause, body=body):
                source = f"try:\n    x = 1\n{clause}\n    {body}\n"
                self.assertEqual(self.python_codes(source), set())

    def test_os_shell_calls_fail_under_each_import_form(self) -> None:
        for source in [
            "import os\nos.system('ls')\n",
            "import os\nos.popen('ls')\n",
            "import os as o\no.system('ls')\n",
            "from os import system\nsystem('ls')\n",
            "from os import popen as p\np('ls')\n",
            "from os import *\nsystem('ls')\n",
        ]:
            with self.subTest(source=source):
                self.assertEqual(self.python_codes(source), {"V010"})

    def test_unrelated_system_calls_pass(self) -> None:
        for source in [
            "import os\nos.path.join('a', 'b')\n",
            "class Host:\n    def system(self):\n        return 1\nHost().system()\n",
            "import platform\nplatform.system()\n",
            "def system(value):\n    return value\nsystem('ls')\n",
        ]:
            with self.subTest(source=source):
                self.assertEqual(self.python_codes(source), set())

    def test_bidirectional_controls_fail_with_line_number(self) -> None:
        source = 'access = "user"\nif access != "user\u202e \u2066// admin\u2069 \u2066":\n    pass\n'
        findings = inspect_python(self.write("bidi.py", source.encode("utf-8")))
        self.assertEqual([(f.code, f.line) for f in findings], [("V011", 2)])

    def test_other_unicode_text_passes(self) -> None:
        self.assertEqual(self.python_codes('name = "café مرحبا"\n'), set())

    def test_json_duplicate_keys_fail_at_any_depth(self) -> None:
        self.assertEqual(self.json_codes('{"a": 1, "a": 2}'), {"V012"})
        self.assertEqual(self.json_codes('{"outer": [{"b": 1, "b": 1}]}'), {"V012"})

    def test_json_same_key_in_separate_objects_passes(self) -> None:
        self.assertEqual(self.json_codes('[{"a": 1}, {"a": 2}]'), set())

    def test_json_nan_and_infinity_fail(self) -> None:
        for text in ['{"a": NaN}', '[Infinity]', '[-Infinity]']:
            with self.subTest(text=text):
                self.assertEqual(self.json_codes(text), {"V013"})

    def test_json_nan_string_passes(self) -> None:
        self.assertEqual(self.json_codes('{"a": "NaN"}'), set())

    def test_json_invalid_utf8_is_a_finding_not_a_crash(self) -> None:
        path = self.write("latin1.json", b'{"name": "caf\xe9"}')
        self.assertEqual({f.code for f in inspect_json(path)}, {"V007"})

    def test_json_output_reports_status_and_findings(self) -> None:
        good = self.write("good.json", b'{"a": 1}')
        bad = self.write("bad.json", b'{"a": NaN}')
        code, output = self.call_main(["--json", str(good)])
        self.assertEqual((code, json.loads(output)), (0, {"status": "pass", "files_listed": 1, "findings": []}))
        code, output = self.call_main(["--json", str(good), str(bad)])
        result = json.loads(output)
        self.assertEqual((code, result["status"], result["files_listed"]), (1, "fail", 2))
        self.assertEqual([f["code"] for f in result["findings"]], ["V013"])

    def test_rule_table_matches_gate_documentation(self) -> None:
        document = (Path(__file__).resolve().parents[1] / "VIBECODE_FAILURE_GATES.md").read_text(encoding="utf-8")
        self.assertEqual(set(re.findall(r"\bV\d{3}\b", document)), set(RULES))

    def test_emitted_codes_are_declared(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "vibecode_gate.py").read_text(encoding="utf-8")
        emitted = set(re.findall(r'"(V\d{3})"', source.split("RULES = {", 1)[1].split("}", 1)[1]))
        self.assertEqual(emitted, set(RULES))


if __name__ == "__main__":
    unittest.main()
