# IDEACHECK: prior work and contribution

Purpose: use NM AI Research's existing prior-work search method before committing to an AI or computing project.

This is a portable edition. It retains mechanism-based searching, complementary search surfaces, comparison verdicts and a search record. Historical case results are omitted. The verdicts below describe what the search found; they do not certify global novelty.

## State what could be contributed

Write one precise research question or proposed contribution. Identify the artefact or setting, mechanism and effect. Do not force a descriptive question into a falsifiable directional assertion merely to fit a form.

## Search by mechanism

Search in layers: the exact artefact or tool; the mechanism or method; its effect; then the more general problem. A broad topic search alone may miss work using different terminology for the same mechanism.

Use the appropriate subset of these surfaces and record omissions:

- arXiv and relevant disciplinary literature, inspecting full text when available.
- ACL Anthology for language-related work and other suitable venue archives for other fields.
- A citation index such as Semantic Scholar or Google Scholar: follow references and later citations around the closest work.
- OpenReview and comparable venue records, including rejected or withdrawn work where relevant. A submission's status does not erase its prior existence or establish its validity.
- The artefact's own GitHub issues, documentation and release history; model or dataset cards; and Hugging Face community discussions where relevant.

Use exact mechanism terms, synonyms and searches for results that should appear if the contribution already exists. Confirm that the search can recover a known relevant example. An empty query result may reflect poor indexing, inaccessible text or unsuitable wording.

Time-box the initial pass to the project's budget. If it remains unclear, record what is missing and choose whether to refine or extend the search. A time limit expiring does not prove that the idea is vague, unstudied or infeasible.

## Compare the closest work

| Finding | Interpretation | Possible next step |
|---|---|---|
| Same contribution already demonstrated | The original novelty claim is not supported | Reframe as replication, learning or another justified question |
| Same mechanism in a different setting | Related prior work exists | Evaluate a clearly labelled extension or replication |
| A general result already includes this case | This is a particular instance | Produce a useful worked case and credit the general result |
| No close match found within the recorded search | Novelty remains provisional | State the search boundary and review the claim before proceeding |

Usefulness is a separate question. Explain who benefits, what existing approach it improves or clarifies, and how that benefit could be checked. A useful replication need not claim a new mechanism.

## Save the search record

Record the date, question, search surfaces, exact queries, access failures, closest papers or projects, the specific difference and the provisional verdict. Include the strongest close match, not only distant examples. Revisit the search before making a final novelty claim, since relevant work may appear during the project.
