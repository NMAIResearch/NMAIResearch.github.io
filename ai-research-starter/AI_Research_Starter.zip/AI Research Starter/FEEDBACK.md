# Pilot feedback entry point

Purpose: direct users to the separate human and agent feedback forms.

Use [FEEDBACK_HUMAN.md](FEEDBACK_HUMAN.md) for the user's experience, decisions and checking effort. Use [FEEDBACK_AGENT.md](FEEDBACK_AGENT.md) for the assistant's actions, evidence, failures and omissions.

Complete the human account before reading the agent account where practical. AI may transcribe or correct spelling at the user's request; disclose the assistance and have the user confirm the wording. Preserve disagreements between the forms.

Record the edition from VERSION. Share redacted observations, without private data or full transcripts by default. One user's experience does not establish general effectiveness or improved outcomes.
