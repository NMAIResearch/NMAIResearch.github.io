# The Deliverable Filter

Purpose: apply NM AI Research's existing seven-lens method to the gap between an announced claim and what can be delivered or observed.

This portable method edition preserves the lenses, route boundary, record structure and judgement limits. Historical worked-case figures and internal trial administration are outside this edition. The wider research sequence is the [public portfolio map](https://nmairesearch.github.io/portfolio-map.html).

## Choose the right question

Use this route for announced capacity, capability, cost, valuation, demand, performance or timing. Define the claim, unit, population, period and output before assessing it. Select a different method for another kind of question; replication, descriptive estimation, comparison, evidence-gap mapping and exploratory work are legitimate routes.

Do not assume an announcement is inflated. The evidence may confirm it, show understatement, reveal mixed results or leave it unresolvable. A series selected only for conspicuously ambitious claims must disclose that selection.

Record the question, primary method, expected output, evidence needed, relevant uncertainty and what could change the conclusion. Freeze consequential choices before final outcome inspection; record later amendments and their reasons. These are instructions, not proof of mechanically enforced or validated research.

## The seven lenses

### 1. Announced and deliverable

What practical constraints affect the claim? Consider physical capacity, data access, quality, time, compute, money, permissions or deployment conditions as appropriate.

Translate the announcement into a defensible estimate or range using those constraints. Show any supported difference and name the assumption most material to the conclusion. If no defensible estimate is possible, state that. Do not manufacture a discount.

### 2. Operators and commitments

What has actually been built, used, funded, contracted, reproduced or delivered? Distinguish plans, demonstrations, binding commitments and operating evidence. Explain what each record can establish.

When an announcement and an observed action diverge, retain both. Neither fluent promotion nor the mere existence of a repository establishes delivery.

### 3. Source incentives and independent corroboration

Record who produced the claim and any relevant incentive. Prefer the primary record for what it directly documents. Look for motive-independent corroboration of consequential empirical claims where it should exist.

Repeated coverage of one original source is one evidence chain. A provider's model card and its press release are not independent measurements. Where independent confirmation is unavailable, retain a single-source label and the limitation; do not invent corroboration or dismiss an authoritative primary record merely because its producer has interests.

### 4. Denominators and comparable baselines

Percentage of what, compared with what, using which population, time period and cost basis? Give numerator, denominator and sample size. Separate measured values from derived values and assumptions.

Normalise system boundaries before comparing numbers. A difference may come from what each method includes or how shared costs are allocated. Do not treat incompatible quantities as competing estimates of the same thing.

### 5. Dependencies and where risk falls

Identify the dependencies most likely to constrain delivery. For an AI project these might include access to a dataset, a hosted model, an evaluation service, specialist review or funding.

State what fails if the dependency changes and who bears that failure. Distinguish an observed dependency from a proposed failure scenario. Do not claim a single point of failure without checking alternatives.

### 6. A dated check and an observable challenge

For a forward claim, state an observable event or condition that would support or weaken it and when to check. For a retrospective claim, identify evidence that would contradict the interpretation.

For a descriptive estimate, specify the measurement and evidence-sufficiency rule rather than inventing a directional prediction. Keep inconclusive outcomes available. A later change to the criterion must remain visible.

### 7. Vintage and provenance

Separate when a condition was true from when it was published, uploaded or retrieved. Record dataset, model, software and paper versions where they matter.

Convert relative timing into explicit dates before checking freshness. Do not present an old snapshot as current merely because the page or video was uploaded recently.

## Record each material finding

| Field | Content |
|---|---|
| ID and route | A stable label and the method being applied |
| Claim | The exact announced proposition |
| Announced value | Its quantity, unit, period and scope, if quantitative |
| Deliverable or observed value | The supported estimate and binding constraint, or why it is not estimable |
| Difference | A reproducible delta or ratio, only where quantities are comparable |
| Source and incentive | Original record, locator, date/version and producer's relevant role |
| Corroboration | Independent support, single-source status or unresolved disagreement |
| Denominator and baseline | Population, comparison and cost/system boundaries |
| Dependencies | The constraint and where consequences fall |
| Follow-up | The event or evidence to check and its date or condition |
| Connections and conflicts | Related findings, common source ancestry and material interests |
| Status | Supported, contradicted, mixed or unresolved, with the basis stated |

## Reproduction and judgement

Keep frozen inputs and a runnable calculation for important derived quantities. A script should reproduce the named result and expose its inputs; it should not print an unsupported fixed interpretation as though that interpretation was calculated.

Automate retrieval records, arithmetic, file checks and clearly defined monitoring where useful. Source relevance, acceptable comparisons, meaning and substantive conclusions still require explicit judgement and review. A checker passing does not make those judgements correct.

Keep effort proportional. Concentrate checking on claims the conclusion depends on. Add structure when it makes the work easier to inspect or repeat. No comparative effectiveness claim follows merely from using this method.
