# Choose an analysis method

Purpose: select an approach that fits the question, evidence and available effort.

Read this after agreeing the initial question. Open the selected route note as needed. This menu is open: propose another established method when it fits better, cite authoritative methodological guidance and explain its requirements. These notes are starter guidance, not complete specialist protocols or validated methods invented by this pack.

## First check the scope

State the question and the decision or learning objective it serves. Identify the intended user, population or setting, outcome and time period. Separate the desired outcome from the proposed measurement. Record accessible data, tools, permissions, time, budget and the user's capacity to check sources.

State what evidence would answer the question and what would leave it unresolved. Attempt a small access or feasibility check before promising substantial work. If the outcome or population is undecided, map the alternatives provisionally; obtain agreement before treating one as the basis for a substantive conclusion.

## Propose a route

| Question | Route note | Minimum output |
|---|---|---|
| What is known, disputed or missing? | [Evidence review](methods/EVIDENCE_REVIEW.md) | Search boundary, source appraisal, disagreements and gaps |
| Does a measure capture the intended outcome? | [Measurement assessment](methods/MEASUREMENT.md) | Construct, reference measure, reliability, change and limits |
| How do people experience, describe or interpret something? | [Qualitative and interpretive enquiry](#qualitative-and-interpretive-enquiry) | Sampling rationale, analytic approach, researcher role and limits |
| How much, how often or for whom? | [Descriptive estimation](methods/DESCRIPTIVE.md) | Population, measurement, sampling and uncertainty |
| Is one approach better, or does an intervention help? | [Comparison and causal questions](methods/COMPARISON.md) | Comparison, outcomes, alternative explanations and uncertainty |
| Can an existing result be reproduced? | [Replication](methods/REPLICATION.md) | Inputs, procedure, agreement criteria and discrepancies |
| Is a project or product useful and feasible? | [Needs and feasibility](methods/FEASIBILITY.md) | User need, alternatives, dependencies and a small practical test |
| Can an announced claim be delivered? | [Deliverable assessment](methods/DELIVERABLE.md) | Constraints, evidence and an estimate where supportable |

Name a primary route and add another only when a distinct part of the question requires it. Explain the choice in a short paragraph: why it fits, the main alternative, required evidence, principal assumption, expected output and main limitation. Confirm material choices with the user. Record later changes.

IDEACHECK.md supports a novelty or contribution question. SOURCE_AND_REPRODUCTION.md applies across routes. A descriptive question needs uncertainty and a measurement plan; do not invent a directional hypothesis. A reporting checklist does not by itself supply a study design or establish source quality.

## Review before expanding

After a small evidence pass, report the strongest supported observation, the most consequential contrary evidence, the main unresolved assumption and whether the proposed next step remains feasible. Supply the human reading task in PROJECT_NOTEBOOK.md. Continue authorised routine work; pause for a decision that changes the question, method, budget or intended use.

Method names and model capability claims do not establish correct execution. Verify the relevant requirements against current authoritative guidance for the field before making consequential methodological claims. Do not describe a rapid exploratory search as a systematic review.

## Qualitative and interpretive enquiry

For interview, case-study, document or discourse questions, choose an established approach appropriate to the discipline and intended interpretation. Record the sampling rationale, material analysed, analytic procedure, researcher role and assumptions, contrary cases and limits. Use suitable supervision and ethics/permission arrangements where needed. Do not force the question into a numerical outcome or causal experiment.

Consult authoritative guidance for the chosen approach. The [SRQR resource at EQUATOR](https://www.equator-network.org/reporting-guidelines/srqr/) is a reporting aid for qualitative studies; it does not supply a complete study design or validate an analysis. For conceptual or normative questions, explicitly state premises, reasoning criteria and counterarguments, and select appropriate disciplinary guidance rather than forcing an empirical route.

ANALYSIS_CHECKS.md supplies optional sensitivity, source-binding and follow-up prompts across applicable routes. It does not require every project to perform all of them.
