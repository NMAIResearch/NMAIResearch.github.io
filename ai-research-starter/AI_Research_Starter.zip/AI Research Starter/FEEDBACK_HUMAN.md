# Research starter feedback: human user

Purpose: record the user's experience, decisions and checking effort in a research starter trial.

Status: candidate form for the next pilot. See VERSION for the pack edition.

Complete this form before reading the agent's feedback where practical. Short answers are enough. Use "not done", "not measured" or "unsure" when appropriate. AI may transcribe answers or correct spelling at your request, but must preserve their meaning. Confirm any assisted wording. The agent's account must not replace or reconcile away your experience.

## Session details

- Date and session label shared with the agent form, without personal identifiers:
- Pack version, or "not stated":
- AI application and model shown in the application, if known:
- Project type and intended use, without private work or participant data:
- Was AI used to prepare these answers? Which parts, and have you confirmed them?

## Experience and decisions

1. **Starting point:** What question or task did you bring? What did you hope to get from the session?

   Answer:

2. **Getting started:** Was it clear which files to read or provide, what to paste, and what would happen next? Where did you need help?

   Answer:

3. **Result:** What did you leave with? Did the question or plan stay the same, become narrower or broader, change direction, or stop? Give the before and after in your own words.

   Answer:

4. **Reasons and control:** What evidence or limitation influenced that decision? Could you explain the reason yourself? Which changes did you choose, reject or feel unable to assess?

   Answer:

5. **Challenge:** Did the assistant question an assumption, overlook something important, or steer the work further than you thought justified? Give a concrete example if possible. "None noticed" is acceptable.

   Answer:

6. **Checking:** Which original sources did you personally open, and which claims or passages did you check? Distinguish reading the assistant's output from checking its sources. Was it clear which sources mattered most?

   Answer:

7. **Reproduction:** What did you personally run or inspect? Did you check a source passage or try a changed input in the worked example? What help was needed? Exact commands can go in the agent form.

   Answer:

8. **Effort and obstacles:** What was confusing, inaccessible, excessive or unnecessary? Could you reasonably check the output? Record setup, research and checking time separately if measured.

   Answer:

9. **Use and limits:** Was it clear that the work was AI-assisted and what assistance should be disclosed? What is useful now, what still needs checking, and what would you be comfortable using the result for? Would you use the pack again, and why?

   Answer:

10. **Changes:** What should change before the next person tries the pack? Name the changes that would matter most to you.

    Answer:

Share only the details needed to understand the experience. Remove credentials, private work and personal data. A session account can document usefulness or difficulty; it does not by itself establish general effectiveness or the correctness of the research.
