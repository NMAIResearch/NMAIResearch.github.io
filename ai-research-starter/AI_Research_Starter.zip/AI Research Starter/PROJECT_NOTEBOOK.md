# Project notebook template

Purpose: keep a small project's scope, evidence, decisions and human checks in one inspectable record.

Copy this template to a new project file. Preserve earlier plans and decisions when revising it. Unknown and not done are valid entries.

## Minimum working record

Start with the scope, decisive claims and precise source passages, the human reading task, actual AI/human contributions, material decisions and unchecked work. Mark other sections not applicable or not yet needed. Add detail when the question requires it; do not make the user fill irrelevant fields merely to complete the template.

## Question queue

The human and agent may propose entries. During research, the agent should recommend relevant questions supported by observed findings and show what existing work could be reused. Offer up to three new prioritised candidates per checkpoint by default, unless the human requests more; check existing entries before adding a duplicate.

For each entry record:

- Queue ID, proposed question, intended use and relation to the current project:
- Date and proposer:
- Triggering source passage or finding, access and support status:
- Existing answer or related queue entry/project checked:
- Reusable source, data, method or code; version and locator:
- What can transfer, its limitations, and what must be rechecked:
- Smallest useful next check, access/resource constraints and priority reason:
- Status: proposed, selected, deferred, combined, answered or archived:
- User's decision, reason and any revisit condition:

A proposed question is not permission to pursue it or a verified claim of novelty.

## Reuse record

Record actual reuse separately from the queue suggestion: original material and version, new question or task, what was reused, changes made, checks performed, remaining limits and resulting output. A link to available material alone is not a reuse run.

## Scope and plan

- Question and question type:
- Intended user, use and output:
- Population or setting, period and exclusions:
- Intended outcome and proposed measurement; unresolved definitions:
- Primary route, why it fits, main alternative and principal assumption:
- Accessible data, tools, permissions, time and budget:
- User's available source-checking effort:
- Initial access or feasibility check:
- Evidence needed; uncertainty and inconclusive conditions:
- Comparison or baseline, where applicable; whether actually run:
- Stopping point and next material decision:
- User's agreement and date:

## Source record

| Source ID | Identity and original link | Version, publication date and observation period | Access date and level | Original text, extraction or generated summary | Precise locator | Permitted saved copy and checksum, or reason absent | Relevant limits |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

## Claim record

| Claim ID | One exact claim | Source ID and passage | Evidence type | Support judgement and reason | Assessor, date and relationship to drafting | Independent review status | Limit or missing evidence |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Evidence type: observed, calculated, interpreted or proposed. Support judgement: supported, partly supported, contradicted or unverified. These labels describe the named assessor's judgement; they do not confer independent verification.

## Human reading task

Choose a short set of sources the next decision depends on, including consequential contrary evidence where available.

| Priority | Claim or decision | Source and exact passage | What to inspect and why | What the check could change | Access barrier | Completed check and finding, or not done; observed or user-reported |
|---|---|---|---|---|---|---|
| | | | | | | |

## Decision history

Add a new dated entry for each material choice: previous position, new choice, evidence or limitation, alternative, expected observable effect, proposer and user's decision. Correct earlier entries additively; preserve their original wording.

## Execution and reproduction

Record exact commands, environment, input identities, output locations, exit status, failures and what each result establishes. Separate calculation reproduction, source-passage checking and changed-input testing.

## AI and human contribution record

Keep a brief factual record of the tools used, material tasks assisted, relevant conflicts and the disclosure wording agreed with the user. Add detail only where the work or destination needs it. Actual source checks and remaining limits belong in the evidence and review records. Use AI_DISCLOSURE.md; settled accurate wording does not need repeated negotiation.

## Separate review record

Use CROSS_REVIEW.md if a separate review is chosen. Record reviewer and relationship to drafting, exact version supplied, prior exposure, checks actually completed, ranked findings, human disposition, revised version and unresolved disagreement. Include the review role in the assistance disclosure.

## Stage review and return

- Supported observation and proposed interpretation:
- Contrary evidence and plausible alternatives:
- Access gaps and unresolved assumptions:
- Any wording that exceeds the checked evidence:
- Completed work and next authorised work:
- Material decision awaiting the user:
- What remains unverified and who would need to check it:
