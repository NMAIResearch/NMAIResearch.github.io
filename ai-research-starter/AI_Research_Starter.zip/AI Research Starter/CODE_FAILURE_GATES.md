# Generated-code failure gates

Purpose: make recurring generated-code defects fail before generated code is handed off, accepted or shipped.

## Mechanical static gate

`code_gate.py` reads only the explicit file paths supplied to it. It parses Python from bytes, so a UTF-8 byte order mark and a declared source encoding are honoured, without importing the file or writing bytecode. Any finding makes it exit 1; `--json` prints one result object with `status`, `files_listed` and `findings`.

| Code | Finding |
|---|---|
| V001 | Python source does not decode or parse. |
| V002 | Bare JSON literal `null`, `true` or `false` in Python. |
| V003 | Direct `eval` or `exec` call. |
| V004 | `shell=True` keyword. |
| V005 | `followlinks=True` keyword. |
| V006 | Broad handler (bare `except`, `Exception`, `BaseException`, or a tuple containing one) whose body only passes or evaluates a constant such as `...`. |
| V007 | JSON that is not valid UTF-8 or does not parse. |
| V008 | Listed file cannot be read: missing, a directory or not permitted. |
| V009 | Listed file is neither `.py` nor `.json`, so the gate cannot check it. |
| V010 | `os.system` or `os.popen`, through `import os`, an alias, `from os import` or `from os import *`. |
| V011 | Bidirectional control character (U+202A to U+202E, U+2066 to U+2069) anywhere in Python source. |
| V012 | Duplicate key within one JSON object. |
| V013 | JSON constant `NaN`, `Infinity` or `-Infinity`. |

The table and the `RULES` mapping in the script are tested for agreement. The script does not discover files, select project scope or validate JSON against schemas. Supply an explicit project-reviewed file list and report omitted files.

## Project-specific verification

Before hand-off, acceptance or release, run and report the applicable project gates:

1. Validate JSON records against each declared schema using representative valid and invalid records. State when a JSON file has no declared schema.
2. Exercise applicable late paths, including network refusal, cleanup, overwrite refusal, path leakage and error reporting.
3. Mutate each declared authority, identity and confinement invariant and show that the mutation fails.
4. Recompute the source, native component, instrument, model and review identities declared by that project.
5. Run the targeted suite under `-W error::ResourceWarning` for Python projects, then run the complete applicable suite or package gate.
6. Reject source-tree bytecode caches after verification for Python projects.
7. Record every inapplicable or skipped gate with its reason.

These checks do not establish security, privacy, semantic correctness, lint coverage, type coverage or test coverage. Independent review remains required.
