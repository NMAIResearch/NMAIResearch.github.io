# Source checks and reproducibility

Purpose: put evidence and repeatable calculations at the centre of the research workflow.

## Search before relying on a supplied URL

Confirm access to live web search before promising current or broad research. Search for original sources, accessible full-text versions, terminology variants and contrary evidence. Record queries, date, search sources, important exclusions and failed access. A fetched URL is one retrieval, not a literature search.

Search snippets and generated summaries can identify leads, but do not establish the original wording or support for the full claim. Open the relevant original passage where possible and preserve its context. If retrieval fails, search for an authorised repository or alternative official source; do not treat repeated snippets as independent corroboration. If only abstracts or summaries are available, keep that limitation attached to the claim.

When live search is unavailable, say so before presenting an answer as current or broadly searched. Agree a supplied-source scope or a small search task for the human.

## Check the source, not just the citation

For each claim important to the conclusion:

1. Open the original paper, dataset, repository, official record or documentation where possible. Record when only an abstract, snippet or secondary account was accessible.
2. Locate the exact supporting passage, table, figure or data field. Read enough surrounding context to retain its qualifiers.
3. Match the claim's population, definition, period, version and units to the source. A similar phrase about another population does not support the same conclusion.
4. Separate what the source directly reports from calculations and interpretations made using it.
5. Look for counter-evidence and shared ancestry. Several websites copying one press release are not independent observations.
6. Preserve missing evidence, uncertainty and disagreement. Do not turn non-retrieval into a finding of absence.

Use the claim table in PROJECT_NOTEBOOK.md: ID, exact claim, source and precise locator, access level, evidence type, support judgement with a reason, named assessor, independent review status and limitation. The source catalogue in the worked example demonstrates inspectable locations and scope limits; it does not guarantee every source statement is true.

## Make the calculation reproducible

Retain the frozen inputs, their origin, units and observation period. Record the code version, environment, parameters and exact command. Keep a separate output directory and an expected result that someone else can compare.

Where interpretation or manual extraction enters, record it explicitly. Reproduction from frozen extracted values does not require pretending that every PDF can be parsed automatically. It does require making the extraction and arithmetic inspectable.

Distinguish these checks:

| Check | What it establishes | What it does not establish |
|---|---|---|
| File hash matches | Bytes agree with the recorded snapshot | Authenticity or truth of the source |
| Input validation passes | Inputs meet the implemented format and constraints | Whether the measurement is appropriate |
| Calculation reproduces | The stated procedure yields the reported result | Whether the interpretation follows |
| Output comparison passes | Generated files agree with the expected outputs | Whether the expected outputs were correct |
| Source-support review | A reviewer assessed whether a source supports a claim | Error-free or exhaustive verification |

Run the supplied example's `--check`, `--explain` and changed-input demonstration as described in README.md. Read its reported unchecked scope. Then trace the explained quantity back to the source passage.

## Challenge the result

Use a simple baseline and disclose the absence of a comparison when none ran. Vary the assumptions most material to the answer where appropriate. Test an input that should be rejected as well as one that should succeed. Preserve failed attempts and exclusions.

For AI experiments, separate development examples from final evaluation. Record the model/version, prompt, relevant settings and data split. Do not describe repeated calls to one model as independent scientific confirmation.

When another person tries the package, record whether the same inputs, command and environment produce the same result. If they do not, investigate the difference before changing the expected answer. A successful rerun supports the stated reproducibility claim; it does not automatically validate the whole research question.

## Preserve accessible evidence

Where permitted, save the version actually inspected in a project sources directory. Record the original URL, access date, publication version, precise passage and a checksum. If saving is unavailable or not permitted, retain the locator and explain the missing copy. Do not claim a complete evidence archive.

Distinguish original text, extracted text and model-generated summaries. A generated summary is a paraphrase until its wording is checked against the original; never place it in quotation marks as a verified quotation. Access level, support judgement and reviewer identity are separate facts.

For an already saved source file, replace the example filename below and use the Python command confirmed in README.md. Run in your terminal:

```sh
python3 -c "import hashlib; from pathlib import Path; print(hashlib.sha256(Path('sources/source.txt').read_bytes()).hexdigest())"
```

This prints the checksum of the saved bytes. It does not retrieve a source, establish permission to copy it, verify authenticity or assess support.

## Give the human a source-reading task

At a consequential decision, rank a short set of source passages by the decision's dependence on them. Include consequential contrary evidence where available. State the claim, original source, exact passage, what to check, the main limitation and what a different reading would change. Explain relevance and study quality in words; do not invent a universal numerical score.

Use PROJECT_NOTEBOOK.md to record completed checks, user-reported checks, access barriers and deferred work separately. Reading the assistant's answer is not source verification. A change of direction based on self-assessed evidence remains provisional.
