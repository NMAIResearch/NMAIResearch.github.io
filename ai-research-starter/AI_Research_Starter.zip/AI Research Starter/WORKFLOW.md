# The continuing research workflow

Purpose: place the project's research and analysis inside a continuing loop with explicit return paths.

The structure follows the author's updated [research map](https://nmairesearch.github.io/portfolio-map.html). The candidate was aligned with the supplied local site source; byte agreement with the live page remains unverified. The map's linked examples illustrate particular stages and do not establish that every study executed every stage.

| Stage | Action | Inspectable record |
|---|---|---|
| Question queue | Retain human questions and relevant agent suggestions arising during research, with the date, reason and reusable work. A lead is not a commitment. | Question, origin, interest and current status |
| Selection and scope | Choose a useful, feasible question; define the outcome and boundary; select a suitable method and check prior work. | Agreed plan, route and limitations |
| Research and challenge | Gather sources, analyse, examine contrary evidence and revise unsupported claims. Return to scope when necessary. | Source and claim records, calculations, stage review and decisions |
| Publish or hand over a version | Obtain the human's decision, identify the exact version and deliver the appropriate evidence and reproduction materials. Preserve earlier versions. | Approved output, AI assistance disclosure and verification limits |
| Align records | Compare the actual released files and version identifiers across the relevant repository, deposit, project copy and project-status record. | Agreement, differences and checks not completed |
| Monitor and reuse | Revisit at stated dates or triggers. Record actual reuse and what was rechecked. | Dated observation or reuse record and its limits |
| Continue or revise | Continue the existing question, issue a correction or extension, or add a new queue entry when the question changes. | Additive decision and links between versions |
| Archive branches | Pause, stop, reframe or combine work while retaining its decision and useful materials. | Status, reason and any condition for revisiting |

Use only the stages that apply. A private project need not be published, and unavailable or inapplicable stages must remain explicit. A negative result is not a reason to suppress work. Archiving does not necessarily mean a novelty check failed.

Record alignment compares released versions and bytes where relevant. A methodological decision log alone does not prove release agreement. Materials offered for reuse do not establish that reuse occurred. Reproduction or reuse does not revalidate underlying sources.

For the research work inside this loop, use RESEARCH_FRAMEWORK.md. For analysis or a scope test, choose a route with METHOD_SELECTION.md. One compact notebook can hold the queue, plan, evidence, decisions and next trigger when the project is small.

## Recommend questions that make useful work reusable

The assistant should help generate the queue. When research reveals a consequential gap, disagreement, unresolved assumption, failed attempt or possible extension, propose a clear question tied to the user's objective. Also check whether existing work already answers it. Do not generate questions merely to fill the queue.

For each candidate record:

- The proposed question, intended use and link to the current project.
- The source passage or observed result that prompted it, with its support and access status. Distinguish a demonstrated limitation from a gap in the search.
- Existing sources, extracted data, calculations, methods or code that could be reused, with versions and locations.
- What that material supplies, what it does not establish, and which dates, populations, definitions, permissions or assumptions need rechecking.
- The smallest useful next check, feasibility constraints and why it merits priority relative to the other candidates.
- An existing queue match or related project, proposer, date, status and the user's decision.

At natural stage reviews, offer up to three new ranked candidates with reasons by default. The user may request more. This is a presentation limit, not an evidence-exclusion rule. The user chooses whether to pursue, defer, combine or archive each candidate. Preserve the current task and its resources until a change is agreed. A literature gap alone establishes neither novelty nor demand.

Reuse can save retrieval, extraction or implementation work, but any time saving must be measured before being claimed. Retain lineage to the original material and its limits. Record actual reuse separately from a suggestion or available reuse materials; reusing a result does not independently verify it.

At versioned handover, include the disclosure from AI_DISCLOSURE.md. Retain actual AI contributions and human checks in the record. Reuse carries forward relevant provenance and adds the contributions and checks of the new work; it does not convert AI-assisted material into wholly human-written work.

Before handover or release, consider CROSS_REVIEW.md for a separate assessment appropriate to the intended use. Record the exact reviewed version, findings, disposition and limits, and retain human control over revision and release.
